import { test, expect, request as apiRequest, type APIRequestContext } from "@playwright/test";

const password = "Court-test-2026!";
function uniqueEmail() { return `smash-test-${Date.now()}-${Math.random().toString(36).slice(2, 8)}@example.com`; }
function tomorrow() { return new Date(Date.now() + 86400000 + 8 * 3600000).toISOString().slice(0, 10); }
test.afterEach(async ({ page }) => {
  try {
    const response = await page.request.get("/api/bookings");
    if (!response.ok()) return;
    const { bookings } = await response.json();
    for (const booking of bookings) if (booking.paymentMode === "demo") await page.request.delete(`/api/bookings/${booking.id}`);
  } catch { /* No browser session was created by an API-only test. */ }
});
async function register(api: APIRequestContext) {
  const response = await api.post("/api/auth/register", { data: { name: "Test Player", email: uniqueEmail(), password } });
  expect(response.status()).toBe(201);
  return response.json();
}

test("reservation lifecycle, server prices, ownership, and double-booking protection", async () => {
  const owner = await apiRequest.newContext({ baseURL: process.env.PLAYWRIGHT_BASE_URL || "http://127.0.0.1:3000" });
  const other = await apiRequest.newContext({ baseURL: process.env.PLAYWRIGHT_BASE_URL || "http://127.0.0.1:3000" });
  const guest = await apiRequest.newContext({ baseURL: process.env.PLAYWRIGHT_BASE_URL || "http://127.0.0.1:3000" });
  let bookingId: string | undefined;
  let otherBookingId: string | undefined;
  try {
    await register(owner); await register(other);
    expect((await guest.get("/api/bookings")).status()).toBe(401);
    const courtResponse = await guest.get("/api/courts");
    const { courts } = await courtResponse.json();
    expect(courts).toHaveLength(4);
    const date = tomorrow();
    const availability = await (await guest.get(`/api/availability?date=${date}`)).json();
    const court = courts[0];
    const hour = Array.from({ length: 16 }, (_, i) => i + 6).find((hour) => !availability.unavailable[court.id]?.includes(hour));
    expect(hour).toBeDefined();
    const data = { courtId: court.id, date, startHour: hour, duration: 1, paymentMethod: "maribank", amount: 1 };
    const created = await owner.post("/api/bookings", { data });
    expect(created.status()).toBe(201);
    const result = await created.json();
    bookingId = result.booking.id;
    expect(result.booking.status).toBe("confirmed");
    expect(result.booking.paymentMode).toBe("demo");
    expect(result.booking.amount).toBe(court.price);
    expect((await other.post("/api/bookings", { data })).status()).toBe(409);
    expect((await guest.get(`/api/bookings/${bookingId}`)).status()).toBe(401);
    expect((await other.get(`/api/bookings/${bookingId}`)).status()).toBe(404);
    const calendar = await owner.get(`/api/bookings/${bookingId}/calendar`);
    expect(calendar.status()).toBe(200);
    const calendarText = await calendar.text();
    expect(calendarText).toContain("BEGIN:VCALENDAR");
    expect(calendarText).toContain("Pickleball");
    expect((await owner.delete(`/api/bookings/${bookingId}`)).status()).toBe(200);
    const cancelled = await (await owner.get(`/api/bookings/${bookingId}`)).json();
    expect(cancelled.booking.status).toBe("refunded");
    const replacement = await other.post("/api/bookings", { data });
    expect(replacement.status()).toBe(201);
    otherBookingId = (await replacement.json()).booking.id;
    const profile = await owner.patch("/api/auth/me", { data: { name: "Updated Player", preferredPayment: "gotyme" } });
    expect((await profile.json()).player.name).toBe("Updated Player");
    expect((await owner.delete("/api/auth/me")).status()).toBe(200);
    expect((await owner.get("/api/bookings")).status()).toBe(401);
  } finally {
    if (bookingId) await owner.delete(`/api/bookings/${bookingId}`);
    if (otherBookingId) await other.delete(`/api/bookings/${otherBookingId}`);
    await owner.dispose(); await other.dispose(); await guest.dispose();
  }
});

test("desktop booking flow creates a visible demo receipt", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByText("Pickleball Court Booking", { exact: true })).toBeVisible();
  await page.screenshot({ path: "artifacts/login-reference.png", animations: "disabled" });
  await page.getByRole("button", { name: "Continue as Guest" }).click();
  await expect(page.getByRole("heading", { name: "Ready to play?" })).toBeVisible();
  await page.screenshot({ path: "artifacts/desktop.png", fullPage: false, animations: "disabled" });
  await page.getByRole("button", { name: new RegExp(`^${new Date(Date.now() + 86400000).toLocaleDateString("en-PH", { weekday: "long", timeZone: "Asia/Manila" })}`) }).click();
  await page.locator(".time-slot:not([disabled])").first().click();
  await page.getByRole("button", { name: "Review booking" }).click();
  await expect(page.getByRole("dialog")).toBeVisible();
  await page.getByLabel("Full name").fill("Browser Test Player");
  await page.getByLabel("Mobile / Email").fill(uniqueEmail());
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByRole("checkbox").check();
  await page.screenshot({ path: "artifacts/checkout.png", fullPage: true });
  await page.getByRole("button", { name: "Confirm demo booking" }).click();
  await expect(page.getByRole("heading", { name: "You’re on the court!" })).toBeVisible();
  await page.screenshot({ path: "artifacts/confirmation.png", animations: "disabled" });
  await page.getByRole("button", { name: "View my bookings" }).click();
  await expect(page.locator(".booking-card")).toHaveCount(1);
  await page.getByRole("button", { name: "Receipt", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Your booking receipt." })).toBeVisible();
  await expect(page.getByText("Demo paid", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Back to my bookings" }).click();
  await page.getByRole("button", { name: "Cancel booking", exact: true }).click();
  await page.getByRole("dialog").getByRole("button", { name: "Cancel booking", exact: true }).click();
  await expect(page.getByRole("heading", { name: "The court is calling." })).toBeVisible();
});

test("mobile layout, calendar view, and payment information", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/");
  await page.screenshot({ path: "artifacts/login-mobile.png", animations: "disabled" });
  await page.getByRole("button", { name: "Continue as Guest" }).click();
  await expect(page.getByRole("heading", { name: "Ready to play?" })).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  await page.screenshot({ path: "artifacts/mobile.png", fullPage: true });
  await page.getByRole("tab", { name: "Calendar view" }).click();
  await expect(page.locator(".schedule-calendar")).toBeVisible();
  await page.getByRole("tab", { name: "List view" }).click();
  await page.getByRole("button", { name: "See all payment options" }).click();
  await expect(page.getByRole("heading", { name: "Your bank. Your game." })).toBeVisible();
  await expect(page.getByText("MariBank and GoTyme are not direct bank-transfer integrations.", { exact: false })).toBeVisible();
  await page.getByRole("button", { name: "Close dialog" }).click();
  await page.getByRole("button", { name: "My profile", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Welcome to SmashCourt." })).toBeVisible();
});
