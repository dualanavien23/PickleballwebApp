import { test, expect } from "@playwright/test";
import { createHmac } from "node:crypto";
import { providerMethods, verifyWebhook } from "../src/lib/payments";

test("bank cards map to the card rail and wallet identifiers stay provider-correct", () => {
  expect(providerMethods("maribank")).toEqual(["card"]);
  expect(providerMethods("gotyme")).toEqual(["card"]);
  expect(providerMethods("card")).toEqual(["card"]);
  expect(providerMethods("gcash")).toEqual(["gcash"]);
  expect(providerMethods("maya")).toEqual(["paymaya"]);
  expect(providerMethods("qrph")).toEqual(["qrph"]);
});

test("webhook signatures require the exact raw payload and a recent timestamp", () => {
  const secret = "unit-test-signing-secret-not-a-credential";
  const raw = JSON.stringify({ data: { id: "test_event", type: "checkout_session.payment.paid" } });
  const timestamp = Math.floor(Date.now() / 1000);
  const signature = createHmac("sha256", secret).update(`${timestamp}.${raw}`).digest("hex");
  expect(verifyWebhook(raw, `t=${timestamp},te=${signature},li=`, secret)).toBe(true);
  expect(verifyWebhook(raw, `t=${timestamp},te=,li=${signature}`, secret)).toBe(true);
  expect(verifyWebhook(raw + " ", `t=${timestamp},te=${signature},li=`, secret)).toBe(false);
  expect(verifyWebhook(raw, `t=${timestamp},te=${"0".repeat(64)},li=`, secret)).toBe(false);
  expect(verifyWebhook(raw, `t=${timestamp - 600},te=${signature},li=`, secret)).toBe(false);
  expect(verifyWebhook(raw, "invalid-signature", secret)).toBe(false);
});
