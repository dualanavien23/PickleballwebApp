import "dotenv/config";
import { test, expect } from "@playwright/test";
import { randomBytes, randomInt } from "node:crypto";
import { eq } from "drizzle-orm";
import { db, pool } from "../src/db";
import { users } from "../src/db/schema";
import { ensureAdmin } from "../src/lib/admin";
import { normalizeIdentifier } from "../src/lib/identity";

test.afterAll(async () => { await pool.end(); });

test("Philippine mobile numbers and emails normalize without losing precision", () => {
  expect(normalizeIdentifier("0917 123 4567")).toEqual({ kind: "phone", value: "+639171234567" });
  expect(normalizeIdentifier("+63 (917) 123-4567")).toEqual({ kind: "phone", value: "+639171234567" });
  expect(normalizeIdentifier("Player@Example.com")).toEqual({ kind: "email", value: "player@example.com" });
  expect(normalizeIdentifier("0917123")).toBeNull();
  expect(normalizeIdentifier("not-an-email@")).toBeNull();
});

test("reference landing supports registration tabs, admin credentials, and persistent guest browsing", async ({ page }) => {
  await page.setViewportSize({ width: 792, height: 720 });
  await page.goto("/");
  await expect(page.getByRole("heading", { name: "SmashCourt", exact: true })).toBeVisible();
  await expect(page.getByText("Pickleball Court Booking", { exact: true })).toBeVisible();
  await expect(page.getByLabel("Mobile / Email")).toBeVisible();
  await expect(page.getByRole("button", { name: "Sign In", exact: true })).toBeVisible();
  await page.screenshot({ path: "artifacts/reference-size.png", animations: "disabled" });
  await page.getByRole("tab", { name: "Register" }).click();
  await expect(page.getByLabel("Full name")).toBeVisible();
  await page.getByRole("tab", { name: "Sign In", exact: true }).click();
  await page.getByRole("button", { name: "Sign In as Admin" }).click();
  await expect(page.getByLabel("Admin email")).toBeVisible();
  await expect(page.getByRole("heading", { name: "Club overview." })).toHaveCount(0); // Never grants access just by clicking.
  await page.getByRole("button", { name: "Back to player sign in" }).click();
  await page.getByRole("button", { name: "Continue as Guest" }).click();
  await expect(page.getByRole("heading", { name: "Ready to play?" })).toBeVisible();
  await expect(page.getByAltText("Solid pickleball paddles and a perforated yellow ball on a sunlit green court")).toBeVisible();
  await page.reload();
  await expect(page.getByRole("heading", { name: "Ready to play?" })).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
});

test("a mobile-number account can sign in through the new form", async ({ page }) => {
  const local = `0917${randomInt(1000000, 9999999)}`;
  const password = `Mobile-${randomBytes(12).toString("hex")}!`;
  const registered = await page.request.post("/api/auth/register", { data: { name: "Mobile Player", identifier: local, password } });
  expect(registered.status()).toBe(201);
  const { player } = await registered.json();
  expect(player.phone).toBe(normalizeIdentifier(local)?.value);
  expect(player.email).toBeNull();
  expect(player.role).toBe("player");
  await page.request.delete("/api/auth/me");
  await page.goto("/");
  await page.getByLabel("Mobile / Email").fill(local);
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByRole("button", { name: "Sign In", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Ready to play?" })).toBeVisible();
  await page.getByRole("button", { name: "My profile", exact: true }).click();
  await expect(page.getByRole("dialog").getByText(player.phone, { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Sign out", exact: true }).click();
  await expect(page.getByText("Pickleball Court Booking", { exact: true })).toBeVisible();
});

test("admin provisioning and overview require a real administrator role", async ({ page }) => {
  const email = `club-owner-${randomBytes(8).toString("hex")}@example.com`;
  const password = randomBytes(24).toString("hex");
  const previousEmail = process.env.ADMIN_EMAIL;
  const previousPassword = process.env.ADMIN_PASSWORD;
  let provisioned = false;
  try {
    expect((await page.request.get("/api/admin/overview")).status()).toBe(401);
    process.env.ADMIN_EMAIL = email; process.env.ADMIN_PASSWORD = password;
    await ensureAdmin(); provisioned = true;
    await page.goto("/");
    await page.getByRole("button", { name: "Sign In as Admin" }).click();
    await page.getByLabel("Admin email").fill(email);
    await page.getByLabel("Password", { exact: true }).fill(password);
    await page.getByRole("button", { name: "Sign In", exact: true }).click();
    await expect(page.getByRole("heading", { name: "Club overview." })).toBeVisible();
    expect((await page.request.get("/api/admin/overview")).status()).toBe(200);
    await page.screenshot({ path: "artifacts/admin.png", animations: "disabled" });
    await page.request.delete("/api/auth/me");
    const playerPassword = "Ordinary-player-2026!";
    expect((await page.request.post("/api/auth/register", { data: { name: "Ordinary Player", identifier: `player-${randomBytes(6).toString("hex")}@example.com`, password: playerPassword } })).status()).toBe(201);
    expect((await page.request.get("/api/admin/overview")).status()).toBe(403);
    const ordinary = await page.request.get("/api/auth/me");
    const { player } = await ordinary.json();
    expect((await page.request.post("/api/auth/login", { data: { identifier: player.email, password: playerPassword, admin: true } })).status()).toBe(403);
  } finally {
    if (provisioned) await db.delete(users).where(eq(users.email, email));
    if (previousEmail === undefined) delete process.env.ADMIN_EMAIL; else process.env.ADMIN_EMAIL = previousEmail;
    if (previousPassword === undefined) delete process.env.ADMIN_PASSWORD; else process.env.ADMIN_PASSWORD = previousPassword;
  }
});
