import { NextResponse } from "next/server";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { courts } from "@/db/schema";
import { ensureVenueSeed } from "@/lib/seed";
import { handleApi } from "@/lib/api";
export async function GET() { return handleApi(async () => { await ensureVenueSeed(); return NextResponse.json({ courts: await db.select().from(courts).orderBy(asc(courts.sortOrder)) }); }); }
