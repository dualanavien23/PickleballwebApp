import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, or, type SQL } from "drizzle-orm";
import { hashPassword, createSession, playerColumns } from "@/lib/auth";
import { handleApi, readJson, AppError } from "@/lib/api";
import { identifierSchema } from "@/lib/identity";

export async function POST(request: NextRequest) {
  return handleApi(async () => {
    const input = z.object({ name: z.string().trim().min(2, "Enter your full name.").max(80), email: z.string().max(254).optional(), identifier: identifierSchema.optional(), password: z.string().min(8, "Use at least 8 characters for your password.").max(128) }).parse(await readJson(request));
    const identity = input.identifier || identifierSchema.parse(input.email || "");
    const conditions: SQL[] = [eq(identity.kind === "email" ? users.email : users.phone, identity.value)];
    
    const [existing] = await db.select({ id: users.id }).from(users).where(or(...conditions)).limit(1);
    if (existing) throw new AppError("That mobile number or email already has an account. Please sign in instead.", 409);
    const [player] = await db.insert(users).values({ name: input.name, email: identity.kind === "email" ? identity.value : null, phone: identity.kind === "phone" ? identity.value : null, passwordHash: await hashPassword(input.password), role: "player" }).returning(playerColumns);
    const response = NextResponse.json({ player }, { status: 201 });
    await createSession(player.id, response, request);
    return response;
  });
}
