import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, verifyPassword } from "@/lib/auth";
import { AppError, handleApi, readJson } from "@/lib/api";
import { identifierSchema } from "@/lib/identity";
import { ensureAdmin } from "@/lib/admin";

const attempts = new Map<string, { count: number; until: number }>();
export async function POST(request: NextRequest) {
  return handleApi(async () => {
    const input = z.object({ email: z.string().max(254).optional(), identifier: identifierSchema.optional(), password: z.string().min(1).max(128), admin: z.boolean().optional().default(false) }).parse(await readJson(request));
    const identity = input.identifier || identifierSchema.parse(input.email || "");
    const key = identity.value;
    const attempt = attempts.get(key);
    if (attempt && attempt.until > Date.now() && attempt.count >= 10) throw new AppError("Too many sign-in attempts. Please try again in 15 minutes.", 429);
    if (input.admin) await ensureAdmin();
    const [user] = await db.select().from(users).where(eq(identity.kind === "email" ? users.email : users.phone, identity.value)).limit(1);
    const valid = await verifyPassword(input.password, user?.passwordHash ?? "00000000000000000000000000000000:" + "0".repeat(128));
    if (!user || !valid) {
      if (attempts.size > 10000) attempts.clear();
      attempts.set(key, { count: attempt && attempt.until > Date.now() ? attempt.count + 1 : 1, until: Date.now() + 900000 });
      throw new AppError("Mobile number, email, or password is incorrect.", 401);
    }
    if (input.admin && user.role !== "admin") throw new AppError("This account does not have administrator access. Use player sign-in instead.", 403);
    attempts.delete(key);
    const player = { id: user.id, name: user.name, email: user.email, phone: user.phone, role: user.role, preferredPayment: user.preferredPayment };
    const response = NextResponse.json({ player });
    await createSession(user.id, response, request, user.role);
    return response;
  });
}
