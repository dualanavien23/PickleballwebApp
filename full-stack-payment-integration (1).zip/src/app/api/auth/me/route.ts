import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { destroySession, getPlayer, requirePlayer, SESSION_COOKIE, playerColumns } from "@/lib/auth";
import { handleApi, readJson } from "@/lib/api";
import { PAYMENT_METHODS } from "@/lib/venue";

export async function GET() { return handleApi(async () => NextResponse.json({ player: await getPlayer() })); }
export async function PATCH(request: NextRequest) {
  return handleApi(async () => {
    const player = await requirePlayer();
    const input = z.object({ name: z.string().trim().min(2).max(80), preferredPayment: z.enum(PAYMENT_METHODS) }).parse(await readJson(request));
    const [updated] = await db.update(users).set(input).where(eq(users.id, player.id)).returning(playerColumns);
    return NextResponse.json({ player: updated });
  });
}
export async function DELETE() {
  return handleApi(async () => { await destroySession(); const response = NextResponse.json({ ok: true }); response.cookies.delete(SESSION_COOKIE); return response; });
}
