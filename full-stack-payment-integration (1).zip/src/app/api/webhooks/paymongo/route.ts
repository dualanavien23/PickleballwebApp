import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { bookings, webhookEvents } from "@/db/schema";
import { verifyWebhook, type CheckoutResource } from "@/lib/payments";
import { getPaidPayment, recordPayment } from "@/lib/booking-service";
import { AppError } from "@/lib/api";

export async function POST(request: NextRequest) {
  const secret = process.env.PAYMONGO_WEBHOOK_SECRET;
  if (!secret) return NextResponse.json({ error: "Webhook not configured." }, { status: 503 });
  const raw = await request.text();
  if (raw.length > 1000000) return NextResponse.json({ error: "Payload too large." }, { status: 413 });
  if (!verifyWebhook(raw, request.headers.get("paymongo-signature") || "", secret)) return NextResponse.json({ error: "Invalid signature." }, { status: 401 });
  try {
    const event = JSON.parse(raw) as { data: { id: string; type: string; livemode: boolean; data: CheckoutResource } };
    if (!event.data?.id || event.data.type !== "checkout_session.payment.paid") return NextResponse.json({ received: true, ignored: true });
    const resource = event.data.data;
    await db.transaction(async (tx) => {
      const inserted = await tx.insert(webhookEvents).values({ id: event.data.id, type: event.data.type }).onConflictDoNothing().returning();
      if (!inserted.length) return;
      const [booking] = await tx.select().from(bookings).where(eq(bookings.reference, resource.attributes.reference_number)).for("update");
      if (!booking || booking.paymentMode !== "live") throw new AppError("Unknown checkout booking.", 404);
      const paid = getPaidPayment(resource, booking, event.data.livemode);
      if (!paid) throw new AppError("No verified paid payment in event.", 400);
      await recordPayment(tx, booking, paid.id, paid.attributes.source?.type || "card", event.data.livemode ? "live" : "test", resource.id);
    });
    return NextResponse.json({ received: true });
  } catch (error) {
    console.error("Webhook processing failed", error instanceof Error ? error.message : "Invalid payload");
    return NextResponse.json({ error: "Webhook processing failed; please retry." }, { status: 400 });
  }
}
