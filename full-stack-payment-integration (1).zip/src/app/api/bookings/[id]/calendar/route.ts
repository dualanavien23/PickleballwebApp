import { NextRequest } from "next/server";
import { z } from "zod";
import { requirePlayer } from "@/lib/auth";
import { AppError, handleApi } from "@/lib/api";
import { findBooking } from "@/lib/booking-service";
const stamp = (date: Date) => date.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
const escape = (value: string) => value.replace(/\\/g, "\\\\").replace(/\n/g, "\\n").replace(/,/g, "\\,").replace(/;/g, "\\;");
export async function GET(_request: NextRequest, context: { params: Promise<{ id: string }> }) {
  return handleApi(async () => {
    const player = await requirePlayer(); const id = z.string().uuid().parse((await context.params).id);
    const booking = await findBooking(id, player.id);
    if (booking.status !== "confirmed") throw new AppError("Only confirmed bookings can be added to your calendar.");
    const start = new Date(`${booking.date}T${String(booking.startHour).padStart(2, "0")}:00:00+08:00`);
    const end = new Date(start.getTime() + booking.duration * 3600000);
    const calendar = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//SmashCourt//Booking//EN", "CALSCALE:GREGORIAN", "BEGIN:VEVENT", `UID:${booking.reference}@smashcourt.local`, `DTSTAMP:${stamp(new Date())}`, `DTSTART:${stamp(start)}`, `DTEND:${stamp(end)}`, `SUMMARY:${escape(`Pickleball · ${booking.courtName} · SmashCourt`)}`, "LOCATION:SmashCourt Club\\, Quezon City\\, Philippines", `DESCRIPTION:${escape(`Booking ${booking.reference}. ${booking.paymentMode === "demo" ? "Demo booking — no real payment. " : ""}Arrive 10 minutes early and bring non-marking shoes.`)}`, "END:VEVENT", "END:VCALENDAR"].join("\r\n");
    return new Response(calendar, { headers: { "Content-Type": "text/calendar; charset=utf-8", "Content-Disposition": `attachment; filename="${booking.reference}.ics"` } });
  });
}
