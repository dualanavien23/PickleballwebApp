import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requirePlayer } from "@/lib/auth";
import { assertSameOrigin, handleApi } from "@/lib/api";
import { cancelBooking, findBooking } from "@/lib/booking-service";
type Context = { params: Promise<{ id: string }> };
export async function GET(_request: NextRequest, context: Context) {
  return handleApi(async () => { const player = await requirePlayer(); const id = z.string().uuid().parse((await context.params).id); return NextResponse.json({ booking: await findBooking(id, player.id) }); });
}
export async function DELETE(request: NextRequest, context: Context) {
  return handleApi(async () => { assertSameOrigin(request); const player = await requirePlayer(); const id = z.string().uuid().parse((await context.params).id); return NextResponse.json({ booking: await cancelBooking(id, player.id) }); });
}
