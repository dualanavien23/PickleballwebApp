import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requirePlayer } from "@/lib/auth";
import { assertSameOrigin, handleApi } from "@/lib/api";
import { demoPayment, findBooking, startCheckout } from "@/lib/booking-service";
export async function POST(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  return handleApi(async () => {
    assertSameOrigin(request);
    const player = await requirePlayer();
    const id = z.string().uuid().parse((await context.params).id);
    const booking = await findBooking(id, player.id);
    const updated = booking.paymentMode === "demo" ? await demoPayment(id, player.id) : await startCheckout(booking, player);
    return NextResponse.json({ booking: await findBooking(updated.id, player.id) });
  });
}
