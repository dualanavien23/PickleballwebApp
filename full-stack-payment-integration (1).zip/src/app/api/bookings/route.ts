import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requirePlayer } from "@/lib/auth";
import { handleApi, readJson } from "@/lib/api";
import { createBooking, listBookings, reconcileExpired } from "@/lib/booking-service";
import { PAYMENT_METHODS } from "@/lib/venue";
import { ensureVenueSeed } from "@/lib/seed";
export async function GET() {
  return handleApi(async () => { const player = await requirePlayer(); await reconcileExpired(); return NextResponse.json({ bookings: await listBookings(player.id) }); });
}
export async function POST(request: NextRequest) {
  return handleApi(async () => {
    const player = await requirePlayer();
    const input = z.object({ courtId: z.string().min(1).max(50), date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), startHour: z.number().int().min(6).max(21), duration: z.number().int().min(1).max(2), paymentMethod: z.enum(PAYMENT_METHODS) }).parse(await readJson(request));
    await ensureVenueSeed();
    await reconcileExpired();
    return NextResponse.json(await createBooking(player, input), { status: 201 });
  });
}
