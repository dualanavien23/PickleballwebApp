import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { ensureVenueSeed } from "@/lib/seed";
import { handleApi, AppError } from "@/lib/api";
import { getAvailability, reconcileExpired } from "@/lib/booking-service";
import { validDate } from "@/lib/venue";
export async function GET(request: NextRequest) {
  return handleApi(async () => {
    const date = z.string().refine(validDate, "Choose a date in the next seven days.").parse(request.nextUrl.searchParams.get("date"));
    await ensureVenueSeed();
    await reconcileExpired();
    return NextResponse.json(await getAvailability(date), { headers: { "Cache-Control": "no-store" } });
  });
}
