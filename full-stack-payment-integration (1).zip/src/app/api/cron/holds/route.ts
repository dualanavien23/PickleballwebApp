import { NextRequest, NextResponse } from "next/server";
import { reconcileExpired } from "@/lib/booking-service";
import { handleApi } from "@/lib/api";
export async function GET(request: NextRequest) {
  return handleApi(async () => {
    const secret = process.env.CRON_SECRET;
    if (!secret || request.headers.get("authorization") !== `Bearer ${secret}`) return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
    await reconcileExpired();
    return NextResponse.json({ ok: true });
  });
}
