import { NextResponse } from "next/server";
import { count, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { bookings, courts } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { handleApi } from "@/lib/api";
import { reconcileExpired } from "@/lib/booking-service";

export async function GET() {
  return handleApi(async () => {
    await requireAdmin();
    await reconcileExpired();
    const [stats] = await db.select({
      total: count(),
      confirmed: sql<number>`count(*) filter (where ${bookings.status} = 'confirmed')`.mapWith(Number),
      liveRevenue: sql<number>`coalesce(sum(${bookings.amount}) filter (where ${bookings.status} = 'confirmed' and ${bookings.paymentMode} = 'live'), 0)`.mapWith(Number),
    }).from(bookings);
    const [courtCount] = await db.select({ total: count() }).from(courts);
    const recent = await db.select({ id: bookings.id, reference: bookings.reference, courtName: courts.name, date: bookings.date, startHour: bookings.startHour, duration: bookings.duration, amount: bookings.amount, status: bookings.status, paymentMode: bookings.paymentMode })
      .from(bookings).innerJoin(courts, eq(bookings.courtId, courts.id)).orderBy(desc(bookings.createdAt)).limit(50);
    return NextResponse.json({ stats: { ...stats, courts: courtCount.total }, bookings: recent }, { headers: { "Cache-Control": "private, no-store" } });
  });
}
