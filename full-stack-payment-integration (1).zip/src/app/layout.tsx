import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import "./auth.css";

export const metadata: Metadata = {
  title: "SmashCourt — Pickleball Court Booking",
  description: "Find your court. Bring your people. Book pickleball courts at SmashCourt with easy payments through cards, MariBank, GoTyme, GCash, and Maya.",
  icons: { icon: "/favicon.svg" },
  applicationName: "SmashCourt",
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#153727" };
export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
