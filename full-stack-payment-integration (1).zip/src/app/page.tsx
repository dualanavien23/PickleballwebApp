import { asc } from "drizzle-orm";
import { db } from "@/db";
import { courts } from "@/db/schema";
import BookingApp from "@/components/booking-app";
import { ensureVenueSeed } from "@/lib/seed";
import { getAvailability } from "@/lib/booking-service";
import { livePaymentMethods, paymentsLive } from "@/lib/payments";
import { getPlayer } from "@/lib/auth";
import { adminConfigured } from "@/lib/admin";
import { manilaDate, type PaymentMethod } from "@/lib/venue";

export const dynamic = "force-dynamic";
export default async function HomePage() {
  await ensureVenueSeed();
  const today = manilaDate();
  const [courtRows, availability, initialPlayer] = await Promise.all([db.select().from(courts).orderBy(asc(courts.sortOrder)), getAvailability(today), getPlayer()]);
  const live = paymentsLive();
  const enabledMethods: PaymentMethod[] = live ? ["maribank", "gotyme", "card", "gcash", "maya", "qrph"].filter((method) => livePaymentMethods().includes(method === "gcash" ? "gcash" : method === "maya" ? "paymaya" : method === "qrph" ? "qrph" : "card")) as PaymentMethod[] : ["maribank", "gotyme", "card", "gcash", "maya", "qrph"];
  return <BookingApp courts={courtRows} today={today} initialAvailability={availability} initialNow={availability.serverNow} initialPlayer={initialPlayer} adminConfigured={adminConfigured()} live={live} enabledMethods={enabledMethods}/>;
}
