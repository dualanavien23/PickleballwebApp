import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Logo, RacketIcon } from "@/components/ui";
export default function NotFound() {
  return <main className="recovery-screen"><Logo/><span className="empty-icon"><RacketIcon size={40}/></span><p className="eyebrow">OUT OF BOUNDS</p><h1>This page isn’t on court.</h1><p>Let’s head back to the club and find your next game.</p><Link className="button primary" href="/"><ArrowLeft size={17}/>Back to SmashCourt</Link></main>;
}
