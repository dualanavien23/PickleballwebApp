"use client";

import { RefreshCw, WifiOff } from "lucide-react";
import { Logo } from "@/components/ui";
export default function ErrorPage({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return <main className="recovery-screen"><Logo/><span className="empty-icon"><WifiOff size={35}/></span><p className="eyebrow">A QUICK TIME-OUT</p><h1>Let’s get you back in the game.</h1><p>We couldn’t load the courts right now. Please check your connection and try again.</p><button className="button primary" onClick={reset}><RefreshCw size={17}/>Try again</button><a className="text-link" href="/api/health">Check service status</a></main>;
}
