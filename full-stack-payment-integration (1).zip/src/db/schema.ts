import { pgTable, text, integer, boolean, timestamp, uuid, date, uniqueIndex, index, check } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const courts = pgTable("courts", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  kind: text("kind").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(),
  capacity: integer("capacity").notNull().default(4),
  popular: boolean("popular").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const courtBlocks = pgTable("court_blocks", {
  id: text("id").primaryKey(),
  courtId: text("court_id").notNull().references(() => courts.id),
  date: date("date").notNull(),
  hour: integer("hour").notNull(),
  reason: text("reason").notNull().default("Court maintenance"),
});

export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  email: text("email").unique(),
  phone: text("phone").unique(),
  name: text("name").notNull(),
  role: text("role").notNull().default("player"),
  passwordHash: text("password_hash").notNull(),
  preferredPayment: text("preferred_payment").notNull().default("maribank"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [check("users_contact_required", sql`${table.email} IS NOT NULL OR ${table.phone} IS NOT NULL`)]);

export const sessions = pgTable("sessions", {
  tokenHash: text("token_hash").primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
}, (table) => [index("sessions_user_idx").on(table.userId)]);

export const bookings = pgTable("bookings", {
  id: uuid("id").defaultRandom().primaryKey(),
  reference: text("reference").notNull().unique(),
  userId: uuid("user_id").notNull().references(() => users.id),
  courtId: text("court_id").notNull().references(() => courts.id),
  date: date("booking_date").notNull(),
  startHour: integer("start_hour").notNull(),
  duration: integer("duration").notNull().default(1),
  amount: integer("amount").notNull(),
  status: text("status").notNull().default("pending"),
  paymentMethod: text("payment_method").notNull(),
  paymentMode: text("payment_mode").notNull().default("demo"),
  checkoutId: text("checkout_id").unique(),
  checkoutUrl: text("checkout_url"),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  paidAt: timestamp("paid_at", { withTimezone: true }),
}, (table) => [index("bookings_user_idx").on(table.userId), index("bookings_status_idx").on(table.status)]);

export const bookingSlots = pgTable("booking_slots", {
  id: uuid("id").defaultRandom().primaryKey(),
  bookingId: uuid("booking_id").notNull().references(() => bookings.id, { onDelete: "cascade" }),
  courtId: text("court_id").notNull().references(() => courts.id),
  date: date("booking_date").notNull(),
  hour: integer("hour").notNull(),
}, (table) => [uniqueIndex("one_reservation_per_slot").on(table.courtId, table.date, table.hour)]);

export const payments = pgTable("payments", {
  id: uuid("id").defaultRandom().primaryKey(),
  bookingId: uuid("booking_id").notNull().references(() => bookings.id),
  providerId: text("provider_id").notNull().unique(),
  amount: integer("amount").notNull(),
  currency: text("currency").notNull().default("PHP"),
  status: text("status").notNull().default("paid"),
  method: text("method").notNull(),
  mode: text("mode").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const webhookEvents = pgTable("webhook_events", {
  id: text("id").primaryKey(),
  type: text("type").notNull(),
  receivedAt: timestamp("received_at", { withTimezone: true }).notNull().defaultNow(),
});
