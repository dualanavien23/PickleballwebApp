"use client";

import { useState, type FormEvent } from "react";
import { ArrowRight, Check, LogOut, UserRound, LoaderCircle, LockKeyhole, ShieldCheck, ArrowLeft } from "lucide-react";
import { Logo, Modal, PaymentMark, PickleballIcon, SecureNote } from "@/components/ui";
import { apiFetch } from "@/lib/api";
import { PAYMENT_METHODS, paymentLabels, playerContact, type PaymentMethod, type Player } from "@/lib/venue";

export type AccountInput = { mode: "register" | "login"; name: string; identifier: string; password: string };
export const emptyAccount: AccountInput = { mode: "register", name: "", identifier: "", password: "" };
export async function authenticatePlayer(input: AccountInput, admin = false) {
  const result = await apiFetch<{ player: Player }>(`/api/auth/${input.mode}`, {
    method: "POST",
    body: JSON.stringify(input.mode === "register" ? { name: input.name, identifier: input.identifier, password: input.password } : { identifier: input.identifier, password: input.password, admin }),
  });
  return result.player;
}
export function AccountFields({ value, onChange, authStyle = false, admin = false }: { value: AccountInput; onChange: (value: AccountInput) => void; authStyle?: boolean; admin?: boolean }) {
  return <div className={`account-fields ${authStyle ? "auth-style" : ""}`}>
    {!admin && <div className="mini-tabs" role="tablist" aria-label="Account access"><button type="button" role="tab" aria-selected={value.mode === "login"} className={value.mode === "login" ? "active" : ""} onClick={() => onChange({ ...value, mode: "login" })}>Sign In</button><button type="button" role="tab" aria-selected={value.mode === "register"} className={value.mode === "register" ? "active" : ""} onClick={() => onChange({ ...value, mode: "register" })}>Register</button></div>}
    {admin && <div className="auth-admin-label"><ShieldCheck size={16}/>Club administrator</div>}
    {value.mode === "register" && !admin && <label className="field-label">Full name<input data-autofocus value={value.name} onChange={(event) => onChange({ ...value, name: event.target.value })} placeholder="Juan Dela Cruz" autoComplete="name" required minLength={2} maxLength={80}/></label>}
    <label className="field-label">{admin ? "Admin email" : "Mobile / Email"}<input data-autofocus={!authStyle && value.mode === "login" ? true : undefined} type={admin ? "email" : "text"} inputMode={admin ? "email" : "text"} value={value.identifier} onChange={(event) => onChange({ ...value, identifier: event.target.value })} placeholder={admin ? "admin@yourclub.com" : "09XX or email@..."} autoComplete="username" autoCapitalize="none" spellCheck={false} required maxLength={254}/></label>
    <label className="field-label">Password<input type="password" value={value.password} onChange={(event) => onChange({ ...value, password: event.target.value })} placeholder={value.mode === "register" ? "At least 8 characters" : "••••••••"} autoComplete={value.mode === "register" ? "new-password" : "current-password"} minLength={value.mode === "register" ? 8 : 1} maxLength={128} required/></label>
    {!authStyle && <p className="field-hint">Just for your bookings. No spam, no membership fees.</p>}
  </div>;
}
export function AuthPanel({ onSuccess, onGuest, adminConfigured }: { onSuccess: (player: Player) => void; onGuest: () => void; adminConfigured: boolean }) {
  const [input, setInput] = useState<AccountInput>({ ...emptyAccount, mode: "login" });
  const [admin, setAdmin] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function submit(event: FormEvent) {
    event.preventDefault(); setBusy(true); setError("");
    try { onSuccess(await authenticatePlayer(input, admin)); }
    catch (error) { setError((error as Error).message); }
    finally { setBusy(false); }
  }
  function switchAdmin(next: boolean) { setAdmin(next); setError(""); setInput({ ...emptyAccount, mode: "login" }); }
  return <div className="auth-panel"><form onSubmit={submit}>
    <AccountFields value={input} onChange={(next) => { setInput(next); setError(""); }} authStyle admin={admin}/>
    {admin && !adminConfigured && <p className="auth-config-note"><LockKeyhole size={14}/><span>Admin access hasn’t been configured. The club owner can enable it with the ADMIN_EMAIL and ADMIN_PASSWORD environment settings.</span></p>}
    {admin && adminConfigured && <p className="auth-admin-hint">Authorized club staff only. Your permissions are verified securely.</p>}
    {error && <p className="form-error" role="alert">{error}</p>}
    <button className="button auth-submit full-width" disabled={busy}>{busy ? <><LoaderCircle size={17} className="spin"/>Signing in…</> : input.mode === "register" ? "Create Account" : "Sign In"}</button>
  </form>
    {admin ? <button className="auth-back" onClick={() => switchAdmin(false)} disabled={busy}><ArrowLeft size={13}/>Back to player sign in</button> : <>
      <div className="auth-divider"><span/><span>or</span><span/></div>
      <button className="button auth-admin-button full-width" disabled={busy} onClick={() => switchAdmin(true)}>Sign In as Admin<LockKeyhole size={14}/></button>
      <p className="auth-guest">Just browsing? <button disabled={busy} onClick={onGuest}>Continue as Guest</button></p>
    </>}
  </div>;
}
export function AuthLanding({ onSuccess, onGuest, adminConfigured }: { onSuccess: (player: Player) => void; onGuest: () => void; adminConfigured: boolean }) {
  return <main className="auth-screen"><div className="auth-brand"><PickleballIcon size={66}/><h1 aria-label="SmashCourt"><Logo light/></h1><p>Pickleball Court Booking</p></div><section className="auth-card" aria-label="Sign in to SmashCourt"><AuthPanel onSuccess={onSuccess} onGuest={onGuest} adminConfigured={adminConfigured}/></section></main>;
}
export function AccountDialog({ onClose, onSuccess, onGuest, adminConfigured }: { onClose: () => void; onSuccess: (player: Player) => void; onGuest: () => void; adminConfigured: boolean }) {
  return <Modal title="Welcome to SmashCourt." eyebrow="PICKLEBALL COURT BOOKING" onClose={onClose}><AuthPanel onSuccess={onSuccess} onGuest={onGuest} adminConfigured={adminConfigured}/></Modal>;
}
export function ProfileDialog({ player, onClose, onUpdate, onLogout, enabledMethods, live }: { player: Player; onClose: () => void; onUpdate: (player: Player) => void; onLogout: () => Promise<void>; enabledMethods: PaymentMethod[]; live: boolean }) {
  const [name, setName] = useState(player.name); const [method, setMethod] = useState(player.preferredPayment); const [busy, setBusy] = useState(false); const [error, setError] = useState(""); const [saved, setSaved] = useState(false);
  async function submit(event: FormEvent) { event.preventDefault(); setBusy(true); setError(""); try { const result = await apiFetch<{ player: Player }>("/api/auth/me", { method: "PATCH", body: JSON.stringify({ name, preferredPayment: method }) }); onUpdate(result.player); setSaved(true); } catch (error) { setError((error as Error).message); } finally { setBusy(false); } }
  return <Modal title="Your player profile." eyebrow="GOOD TO HAVE YOU HERE" onClose={onClose}><div className="profile-summary"><span className="avatar large">{player.name.charAt(0).toUpperCase()}</span><div><strong>{player.name}</strong><p>{playerContact(player)}</p><span className="small-tag">{player.role === "admin" ? "Club administrator" : "Community player"}</span></div></div><form onSubmit={submit}><label className="field-label">Display name<input value={name} onChange={(event) => { setName(event.target.value); setSaved(false); }} required minLength={2} maxLength={80}/></label><label className="field-label">Preferred way to pay<select value={method} onChange={(event) => { setMethod(event.target.value); setSaved(false); }}>{PAYMENT_METHODS.map((method) => <option key={method} value={method} disabled={live && !enabledMethods.includes(method)}>{paymentLabels[method]}{live && !enabledMethods.includes(method) ? " · demo only" : ""}</option>)}</select></label><div className="inline-notice"><PaymentMark method={method as PaymentMethod} compact/><span>{live ? "Your preference is used at checkout. You can change it any time." : "You’re in demo mode. Explore payments without real charges."}</span></div>{error && <p className="form-error" role="alert">{error}</p>}<button className="button primary full-width" disabled={busy}>{busy ? <LoaderCircle size={18} className="spin"/> : saved ? <><Check size={18}/>Profile saved</> : <>Save changes<ArrowRight size={18}/></>}</button></form><button className="button ghost full-width logout-button" disabled={busy} onClick={async () => { setBusy(true); try { await onLogout(); } catch (error) { setError((error as Error).message); setBusy(false); } }}><LogOut size={17}/>Sign out</button></Modal>;
}
export function SignedOutProfile({ onSignIn, onBook }: { onSignIn: () => void; onBook: () => void }) {
  return <div className="empty-state signed-out"><span className="empty-icon"><UserRound size={34}/></span><p className="eyebrow">THERE’S ROOM FOR YOU HERE</p><h2>Your game. Your space.</h2><p>Create a free player account to book a pickleball court, save your payment preference, and keep your match history in one place.</p><button className="button primary" onClick={onSignIn}>Sign in or create account<ArrowRight size={18}/></button><button className="text-link" onClick={onBook}>Explore the courts first</button></div>;
}
