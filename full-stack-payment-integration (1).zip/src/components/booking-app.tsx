"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import { ArrowRight, ArrowUpRight, Bell, CalendarDays, CalendarCheck2, CarFront, Check, ChevronLeft, ChevronRight, Clock3, Flame, Globe2, Info, List, LoaderCircle, MapPin, ShieldCheck, ShoppingBag, ShowerHead, UserRound, Users, Wifi, X } from "lucide-react";
import { Logo, CourtArt, PaymentMark, RacketIcon, PickleballIcon } from "@/components/ui";
import { AccountDialog, AuthLanding, ProfileDialog, SignedOutProfile } from "@/components/account-dialog";
import { CheckoutDialog, BookingSuccess, type Selection, type BookingResult } from "@/components/checkout-dialog";
import { BookingsView, AlertsView } from "@/components/bookings-view";
import { InfoDialog, type InfoPage } from "@/components/info-dialog";
import { AdminView } from "@/components/admin-view";
import { apiFetch } from "@/lib/api";
import { CLOSE_HOUR, OPEN_HOUR, dateLabel, formatHour, manilaDate, peso, playerContact, timeRange, type Availability, type Booking, type Court, type PaymentMethod, type Player } from "@/lib/venue";

type Props = { courts: Court[]; today: string; initialAvailability: Availability; initialNow: number; initialPlayer: Player | null; adminConfigured: boolean; live: boolean; enabledMethods: PaymentMethod[] };
type View = "book" | "bookings" | "alerts" | "profile" | "admin";
const hours = Array.from({ length: CLOSE_HOUR - OPEN_HOUR }, (_, index) => OPEN_HOUR + index);

export default function BookingApp({ courts, today, initialAvailability, initialNow, initialPlayer, adminConfigured, live, enabledMethods }: Props) {
  const [now, setNow] = useState(initialNow);
  const [view, setView] = useState<View>(initialPlayer?.role === "admin" ? "admin" : "book");
  const [sessionReady, setSessionReady] = useState(Boolean(initialPlayer));
  const [enteredAsGuest, setEnteredAsGuest] = useState(false);
  const [layout, setLayout] = useState<"list" | "calendar">("list");
  const [date, setDate] = useState(today);
  const [availability, setAvailability] = useState(initialAvailability);
  const [availabilityLoading, setAvailabilityLoading] = useState(false);
  const [selection, setSelection] = useState<Selection | null>(null);
  const [player, setPlayer] = useState<Player | null>(initialPlayer);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [bookingsLoading, setBookingsLoading] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [success, setSuccess] = useState<Booking | null>(null);
  const [info, setInfo] = useState<InfoPage | null>(null);
  const [toast, setToast] = useState<{ message: string; id: number } | null>(null);
  const [readIds, setReadIds] = useState<string[]>([]);
  const notify = useCallback((message: string) => setToast({ message, id: Date.now() }), []);
  const refreshBookings = useCallback(async () => {
    setBookingsLoading(true);
    try { const result = await apiFetch<{ bookings: Booking[] }>("/api/bookings"); setBookings(result.bookings); }
    finally { setBookingsLoading(false); }
  }, []);
  const refreshAvailability = useCallback(async () => {
    const result = await apiFetch<Availability>(`/api/availability?date=${date}`); setAvailability(result);
  }, [date]);

  useEffect(() => {
    let active = true;
    async function initialize() {
      try {
        let guest = false;
        try {
          guest = localStorage.getItem("smashcourt-guest") === "1";
          if (new URLSearchParams(window.location.search).has("signin")) { guest = false; localStorage.removeItem("smashcourt-guest"); window.history.replaceState({}, "", window.location.pathname); }
        } catch { /* Guest browsing also works without local storage. */ }
        if (!active) return;
        setEnteredAsGuest(guest);
        const account = await apiFetch<{ player: Player | null }>("/api/auth/me");
        if (!active) return;
        setPlayer(account.player);
        try { const saved = localStorage.getItem(`smashcourt-alerts-${account.player?.id || "guest"}`); if (saved) { const parsed: unknown = JSON.parse(saved); if (Array.isArray(parsed)) setReadIds(parsed.filter((value): value is string => typeof value === "string")); } } catch { /* Storage is optional. */ }
        if (account.player) {
          if (account.player.role === "admin") setView("admin");
          await refreshBookings();
          const query = new URLSearchParams(window.location.search);
          const bookingId = query.get("booking");
          if (bookingId && /^[0-9a-f-]{36}$/i.test(bookingId)) {
            try {
              if (query.get("payment") === "return") await apiFetch(`/api/bookings/${bookingId}/sync`, { method: "POST" });
              else notify("Checkout returned you here. Your pending reservation is in My bookings.");
              await refreshBookings(); setView("bookings");
            } catch { notify("We’re checking your payment. Refresh My bookings for the latest status."); setView("bookings"); }
            window.history.replaceState({}, "", window.location.pathname);
          }
        }
      } catch { if (active) notify("We couldn’t refresh your account. You can still browse the courts."); }
      finally { if (active) setSessionReady(true); }
    }
    void initialize();
    return () => { active = false; };
  }, [notify, refreshBookings]);

  useEffect(() => {
    let active = true;
    async function load(silent = false) {
      if (!silent) setAvailabilityLoading(true);
      try { const result = await apiFetch<Availability>(`/api/availability?date=${date}`); if (active) setAvailability(result); }
      catch (error) { if (active) notify((error as Error).message); }
      finally { if (active) setAvailabilityLoading(false); }
    }
    void load();
    const timer = setInterval(() => { if (document.visibilityState === "visible") void load(true); }, 30000);
    return () => { active = false; clearInterval(timer); };
  }, [date, notify]);

  useEffect(() => {
    if (!player) return;
    const timer = setInterval(() => { if (document.visibilityState === "visible") void refreshBookings().catch(() => {}); }, 60000);
    return () => clearInterval(timer);
  }, [player, refreshBookings]);
  useEffect(() => { const timer = setInterval(() => setNow(Date.now()), 30000); return () => clearInterval(timer); }, []);
  useEffect(() => { if (!toast) return; const timer = setTimeout(() => setToast(null), 5500); return () => clearTimeout(timer); }, [toast]);

  function navigate(next: View) { setView(next); window.scrollTo({ top: 0, behavior: "smooth" }); }
  function chooseDate(next: string) { setDate(next); setSelection(null); }
  function chooseSlot(courtId: string, hour: number) {
    setSelection((current) => {
      if (current?.courtId !== courtId) return { courtId, hours: [hour] };
      if (current.hours.includes(hour)) return current.hours.length === 1 ? null : { courtId, hours: current.hours.filter((value) => value !== hour) };
      if (current.hours.length === 1 && Math.abs(current.hours[0] - hour) === 1) return { courtId, hours: [...current.hours, hour].sort((a, b) => a - b) };
      return { courtId, hours: [hour] };
    });
  }
  function markRead(ids: string[]) {
    const unique = [...new Set(ids)]; setReadIds(unique);
    try { localStorage.setItem(`smashcourt-alerts-${player?.id || "guest"}`, JSON.stringify(unique)); } catch { /* Storage is optional. */ }
  }
  function continueAsGuest() {
    setEnteredAsGuest(true); setAuthOpen(false);
    try { localStorage.setItem("smashcourt-guest", "1"); } catch { /* Storage is optional. */ }
    notify("Welcome, guest! Browse the courts, then sign in when you’re ready to book.");
  }
  async function onAccount(next: Player) {
    setPlayer(next); setAuthOpen(false); setEnteredAsGuest(false); setSessionReady(true); setView(next.role === "admin" ? "admin" : "book");
    try { localStorage.removeItem("smashcourt-guest"); } catch { /* Storage is optional. */ }
    try { await refreshBookings(); } catch { notify("Signed in. Your bookings will load when you open My bookings."); }
    notify(`Welcome ${next.name.split(" ")[0]}! Let’s make it a match.`);
  }
  async function onLogout() { await apiFetch("/api/auth/me", { method: "DELETE" }); setPlayer(null); setBookings([]); setProfileOpen(false); setEnteredAsGuest(false); setView("book"); setReadIds([]); try { localStorage.removeItem("smashcourt-guest"); } catch { /* Storage is optional. */ } notify("You’re signed out. See you on court!"); }
  async function onBooked(result: BookingResult, next: Player) {
    setPlayer(next); setCheckoutOpen(false); setSelection(null);
    await Promise.all([refreshBookings(), refreshAvailability()]);
    if (result.booking.checkoutUrl && result.booking.status === "pending") { window.location.assign(result.booking.checkoutUrl); return; }
    if (result.booking.status === "confirmed") setSuccess(result.booking);
    else { setView("bookings"); notify(result.checkoutError || "Your court is on hold. Complete payment from My bookings."); }
  }
  async function onPay(booking: Booking) {
    try {
      if (booking.paymentMode === "live" && booking.checkoutUrl) { window.location.assign(booking.checkoutUrl); return; }
      const result = await apiFetch<{ booking: Booking }>(`/api/bookings/${booking.id}/pay`, { method: "POST" });
      await refreshBookings();
      if (result.booking.checkoutUrl && result.booking.status === "pending") window.location.assign(result.booking.checkoutUrl);
      else if (result.booking.status === "confirmed") { setSuccess(result.booking); await refreshAvailability(); }
    } catch (error) { notify((error as Error).message); }
  }
  const selectedCourt = courts.find((court) => court.id === selection?.courtId);
  const alertCount = bookings.filter((booking) => !readIds.includes(booking.id)).length + (readIds.includes("welcome") ? 0 : 1) + (readIds.includes("payments") ? 0 : 1);
  const upcomingCount = bookings.filter((booking) => booking.status === "confirmed" && new Date(`${booking.date}T${String(booking.startHour + booking.duration).padStart(2, "0")}:00:00+08:00`).getTime() > now).length;
  const openCourts = courts.filter((court) => hours.some((hour) => !availability.unavailable[court.id]?.includes(hour) && !availability.past.includes(hour))).length;
  const dates = Array.from({ length: 7 }, (_, index) => new Date(new Date(`${today}T12:00:00Z`).getTime() + index * 86400000).toISOString().slice(0, 10));
  const greeting = new Intl.DateTimeFormat("en-PH", { timeZone: "Asia/Manila", hour: "numeric", hourCycle: "h23" }).format(new Date(now));

  if (!sessionReady) return <main className="auth-screen session-loading" aria-label="Loading your session"><PickleballIcon size={64}/><Logo light/><LoaderCircle size={20} className="spin"/><p>Getting your court ready…</p></main>;
  if (!player && !enteredAsGuest) return <AuthLanding onSuccess={(next) => { void onAccount(next); }} onGuest={continueAsGuest} adminConfigured={adminConfigured}/>;

  return <div className="app-shell">
    <header className="site-header"><div className="header-grid"/><div className="header-inner"><div className="topbar"><button className="brand-button" aria-label="SmashCourt home" onClick={() => navigate("book")}><Logo light/></button><div className="header-actions"><button className="location-button" onClick={() => setInfo("venue")}><MapPin size={15}/><span>Quezon City, PH</span><ChevronRight size={13}/></button><span className="header-divider"/><button className="icon-button header-bell" aria-label={`Open alerts, ${alertCount} unread`} onClick={() => navigate("alerts")}><Bell size={21}/>{alertCount > 0 && <span className="notification-dot"/>}</button><button className="avatar header-avatar" aria-label={player ? "Open your profile" : "Sign in or create an account"} onClick={() => player ? setProfileOpen(true) : setAuthOpen(true)}>{player ? player.name.charAt(0).toUpperCase() : "G"}</button></div></div><div className="hero-copy"><p className="hero-greeting">Good {Number(greeting) < 12 ? "morning" : Number(greeting) < 18 ? "afternoon" : "evening"}{player ? `, ${player.name.split(" ")[0]}` : enteredAsGuest ? ", guest" : ", player"}<span>.</span></p><h1>Ready to <span>play?</span><PickleballIcon size={43}/></h1><p className="hero-description">Pickleball. Your people. Your next great game.</p><div className="hero-badges"><span className="open-badge"><span className="live-dot"/>{openCourts} courts open</span><span><Clock3 size={13}/>6 AM – 10 PM</span><button onClick={() => setInfo("payments")}><ShieldCheck size={13}/>Cards, GCash & Maya<ArrowUpRight size={12}/></button></div></div><CourtArt/><div className="hero-side-note"><span className="tiny-line"/>LESS SCROLLING. MORE SMASHING.</div></div></header>
    <main className="main-container">
      {view === "admin" && player?.role === "admin" && <AdminView onBrowse={() => navigate("book")} onLogout={onLogout}/>}
      {view === "book" && <>
        <div className="view-switch" role="tablist" aria-label="Court schedule view"><button role="tab" aria-selected={layout === "list"} className={layout === "list" ? "active" : ""} onClick={() => setLayout("list")}><List size={17}/>List view</button><button role="tab" aria-selected={layout === "calendar"} className={layout === "calendar" ? "active" : ""} onClick={() => setLayout("calendar")}><CalendarDays size={17}/>Calendar view</button></div>
        <div className="date-toolbar"><div className="date-strip" aria-label="Choose a booking date">{dates.map((item, index) => <button key={item} className={`date-button ${date === item ? "selected" : ""}`} aria-pressed={date === item} aria-label={dateLabel(item, { weekday: "long", month: "long", day: "numeric" })} onClick={() => chooseDate(item)}><span>{index === 0 ? "TODAY" : dateLabel(item, { weekday: "short" }).toUpperCase()}</span><strong>{dateLabel(item, { day: "numeric" })}</strong>{date === item && <span className="date-selected-dot"/>}</button>)}</div><div className="date-meta"><div className="month-controls"><button className="icon-button" aria-label="Previous date" disabled={date === dates[0]} onClick={() => chooseDate(dates[Math.max(0, dates.indexOf(date) - 1)])}><ChevronLeft size={16}/></button><strong>{dateLabel(date, { month: "long", year: "numeric" })}</strong><button className="icon-button" aria-label="Next date" disabled={date === dates[6]} onClick={() => chooseDate(dates[Math.min(6, dates.indexOf(date) + 1)])}><ChevronRight size={16}/></button></div><span><Globe2 size={12}/>Philippine time (PHT)</span></div></div>
        <div className="section-heading"><div><h2>Find your court<span>.</span></h2><p>Pick a slot. Bring your A-game.</p></div><div className="slot-legend"><span><i className="available"/>Available</span><span><i className="unavailable"/>Unavailable</span><span><i className="selected"/>Selected</span></div></div>
        <div className={`booking-layout ${layout === "calendar" ? "calendar-layout" : ""}`}>
          <aside className="club-sidebar"><article className="club-card"><div className="club-image"><Image src="/images/pickleball-club.jpg" alt="Solid pickleball paddles and a perforated yellow ball on a sunlit green court" fill sizes="(max-width: 760px) 100vw, 300px" priority/><span className="image-label"><span className="live-dot"/>YOUR HOME COURT</span><span className="image-sport"><PickleballIcon size={28}/></span></div><div className="club-card-content"><div className="club-title"><h3>SmashCourt Club</h3><ArrowUpRight size={19}/></div><p className="club-location"><MapPin size={13}/>Quezon City, Metro Manila</p><div className="club-hours"><Clock3 size={14}/><span>Open daily</span><strong>6 AM – 10 PM</strong></div><div className="club-amenities"><span><CarFront size={16}/>Parking</span><span><ShowerHead size={16}/>Changing rooms</span><span><Wifi size={16}/>Free Wi-Fi</span><span><ShoppingBag size={16}/>Gear rental</span></div><button className="club-details-button" onClick={() => setInfo("venue")}>Get to know the club<ArrowRight size={16}/></button></div></article>
            <article className="payments-card"><span className="eyebrow">EASY FROM START TO FINISH</span><h3>Play now. Pay your way.</h3><p>Your favorite banks. Your go-to cards.</p><div className="bank-logos"><PaymentMark method="maribank"/><span className="logo-separator"/><PaymentMark method="gotyme"/></div><div className="more-payment-logos"><PaymentMark method="card" compact/><span/><PaymentMark method="gcash" compact/><PaymentMark method="maya" compact/></div><button className="text-link" onClick={() => setInfo("payments")}>See all payment options<ArrowUpRight size={14}/></button><div className="payments-security"><ShieldCheck size={13}/>{live ? "Secure checkout by PayMongo" : "Try it safe with demo checkout"}</div></article>
            <button className="help-card" onClick={() => setInfo("how")}><span><RacketIcon size={26}/></span><div><strong>First game here?</strong><p>Booking is as easy as 1, 2, 3.</p><span>Here’s how it works<ArrowRight size={13}/></span></div></button>
            <p className="sidebar-footnote">A little friendly competition.<br/>A whole lot of good company.</p>
          </aside>
          <section className="courts-area" aria-label="Court availability" aria-busy={availabilityLoading}>
            {availabilityLoading && <div className="availability-progress"/>}
            {layout === "list" ? <div className="court-grid">{courts.map((court) => <CourtCard key={court.id} court={court} availability={availability} selection={selection} onSlot={chooseSlot} onReview={() => setCheckoutOpen(true)}/>)}</div> : <div className="calendar-wrap"><div className="schedule-calendar"><div className="calendar-row calendar-header"><div><Clock3 size={17}/><span>PHT</span></div>{courts.map((court) => <div key={court.id}><strong>{court.name}</strong><span>{peso(court.price)} / hour</span></div>)}</div>{hours.map((hour) => <div className="calendar-row" key={hour}><div className="calendar-time">{formatHour(hour)}</div>{courts.map((court) => { const selected = selection?.courtId === court.id && selection.hours.includes(hour); const past = availability.past.includes(hour); const unavailable = availability.unavailable[court.id]?.includes(hour); return <button key={court.id} className={`calendar-slot ${selected ? "selected" : ""} ${unavailable || past ? "unavailable" : ""}`} disabled={unavailable || past || availabilityLoading} aria-pressed={selected} aria-label={`${court.name}, ${formatHour(hour)}, ${past ? "past" : unavailable ? "unavailable" : "available"}`} onClick={() => chooseSlot(court.id, hour)}>{selected ? <><Check size={13}/>Selected</> : past ? "—" : unavailable ? "Unavailable" : <>{peso(court.price)}<span>Book</span></>}</button>; })}</div>)}</div></div>}
            <div className="court-bottom-note"><Info size={15}/><p>Good to know: select up to 2 consecutive hours on the same court. All prices are per court, for up to 4 players.</p></div>
          </section>
        </div>
        <div className="venue-disclaimer"><span>© {new Date(now).getFullYear()} SmashCourt</span><span>Demo venue · {live ? "Live payments enabled" : "No real charges in demo mode"}</span><button onClick={() => setInfo("terms")}>Booking policy</button><a href="/smashcourt-source.zip" download>Download source code</a></div>
      </>}
      {view === "bookings" && <BookingsView bookings={bookings} now={now} loading={bookingsLoading} player={player} onRefresh={refreshBookings} onBook={() => navigate("book")} onSignIn={() => setAuthOpen(true)} onPay={onPay} notify={notify}/>}
      {view === "alerts" && <AlertsView bookings={bookings} readIds={readIds} onRead={markRead} onBookings={() => navigate("bookings")} onBook={() => navigate("book")}/>}
      {view === "profile" && <section className="secondary-view"><div className="page-heading"><div><p className="eyebrow">THE PLAYER BEHIND THE GAME</p><h1>Your profile<span>.</span></h1></div></div>{player ? <div className="profile-page-card"><span className="avatar large">{player.name.charAt(0)}</span><h2>{player.name}</h2><p>{playerContact(player)}</p><button className="button primary" onClick={() => setProfileOpen(true)}><UserRound size={17}/>Manage my profile</button></div> : <SignedOutProfile onSignIn={() => setAuthOpen(true)} onBook={() => navigate("book")}/>}</section>}
    </main>
    {selection && selectedCourt && view === "book" && !checkoutOpen && <div className="selection-bar"><span className="selection-icon"><RacketIcon size={28}/></span><div className="selection-copy"><strong>{selectedCourt.name}<span> · {selection.hours.length} {selection.hours.length === 1 ? "hour" : "hours"}</span></strong><p>{dateLabel(date)} · {timeRange(Math.min(...selection.hours), selection.hours.length)}</p></div><strong className="selection-total">{peso(selectedCourt.price * selection.hours.length)}</strong><button className="icon-button selection-clear" aria-label="Clear selected slots" onClick={() => setSelection(null)}><X size={18}/></button><button className="button lime" onClick={() => setCheckoutOpen(true)}>Review booking<ArrowRight size={17}/></button></div>}
    <nav className="bottom-nav" aria-label="Main navigation"><div className="bottom-nav-inner"><button className={view === "book" ? "active" : ""} onClick={() => navigate("book")}><span><RacketIcon size={24}/></span><strong>Book a court</strong></button><button className={view === "alerts" ? "active" : ""} onClick={() => navigate("alerts")}><span><Bell size={22}/>{alertCount > 0 && <i className="nav-dot"/>}</span><strong>Alerts</strong></button><button className={view === (player?.role === "admin" ? "admin" : "bookings") ? "active" : ""} onClick={() => navigate(player?.role === "admin" ? "admin" : "bookings")}><span>{player?.role === "admin" ? <ShieldCheck size={22}/> : <CalendarCheck2 size={22}/>} {upcomingCount > 0 && <i className="nav-count">{upcomingCount}</i>}</span><strong>{player?.role === "admin" ? "Club overview" : "My bookings"}</strong></button><button className={view === "profile" || profileOpen ? "active" : ""} onClick={() => player ? setProfileOpen(true) : setAuthOpen(true)}><span><UserRound size={22}/></span><strong>My profile</strong></button></div><span className="nav-side-copy">GOOD GAMES START HERE.</span></nav>
    {toast && <div className="toast" role="status" key={toast.id}><Info size={18}/><span>{toast.message}</span><button aria-label="Dismiss notification" onClick={() => setToast(null)}><X size={16}/></button></div>}
    {authOpen && <AccountDialog onClose={() => setAuthOpen(false)} onSuccess={(next) => { void onAccount(next); }} onGuest={continueAsGuest} adminConfigured={adminConfigured}/>}
    {profileOpen && player && <ProfileDialog player={player} live={live} enabledMethods={enabledMethods} onClose={() => setProfileOpen(false)} onUpdate={(next) => { setPlayer(next); notify("Profile updated. Make yourself at home."); }} onLogout={onLogout}/>}
    {info && <InfoDialog page={info} live={live} enabledMethods={enabledMethods} onClose={() => setInfo(null)} onBook={() => { setInfo(null); navigate("book"); }}/>}
    {checkoutOpen && selectedCourt && selection && <CheckoutDialog court={selectedCourt} selection={selection} date={date} availability={availability} player={player} live={live} enabledMethods={enabledMethods} onClose={() => setCheckoutOpen(false)} onPlayer={setPlayer} onBooked={(result, next) => { void onBooked(result, next).catch((error) => notify((error as Error).message)); }}/>}
    {success && <BookingSuccess booking={success} onClose={() => setSuccess(null)} onViewBookings={() => { setSuccess(null); navigate("bookings"); }}/>}
  </div>;
}

function CourtCard({ court, availability, selection, onSlot, onReview }: { court: Court; availability: Availability; selection: Selection | null; onSlot: (courtId: string, hour: number) => void; onReview: () => void }) {
  const unavailable = availability.unavailable[court.id] || [];
  const selected = selection?.courtId === court.id ? selection.hours : [];
  const availableCount = hours.filter((hour) => !unavailable.includes(hour) && !availability.past.includes(hour)).length;
  return <article className={`court-card ${selected.length ? "has-selection" : ""}`}><div className="court-card-header"><div className="court-header-lines"/><div className="court-name-block"><div className="court-title"><h3>{court.name}</h3>{court.popular && <span className="popular-badge"><Flame size={11}/>Popular</span>}</div><span className={`kind-tag ${court.kind.toLowerCase()}`}>{court.kind === "Indoor" ? <SnowflakeIcon/> : <SunIcon/>}{court.kind}</span></div><div className="court-price"><strong>{peso(court.price)}</strong><span>per hour</span></div></div><div className="court-card-body"><div className="court-body-label"><span>{court.description}</span><strong>{availableCount} slots left</strong></div><div className="time-slots">{hours.map((hour) => { const isSelected = selected.includes(hour); const past = availability.past.includes(hour); const booked = unavailable.includes(hour); return <button key={hour} className={`time-slot ${isSelected ? "selected" : ""} ${booked ? "booked" : ""} ${past ? "past" : ""}`} disabled={booked || past} aria-pressed={isSelected} title={`${court.name} · ${formatHour(hour)} · ${past ? "Time has passed" : booked ? "Unavailable" : `${peso(court.price)} per hour`}`} aria-label={`${court.name}, ${formatHour(hour)}, ${past ? "past" : booked ? "unavailable" : "available"}`} onClick={() => onSlot(court.id, hour)}>{isSelected && <Check size={11}/>}<span>{formatHour(hour)}</span></button>; })}</div></div><div className="court-card-footer"><span><Users size={14}/>Up to {court.capacity} players</span><button className={`button small ${selected.length ? "primary" : "slot-placeholder"}`} disabled={!selected.length} onClick={onReview}>{selected.length ? <>Book this court<ArrowRight size={14}/></> : "Select a slot"}</button></div></article>;
}
function SnowflakeIcon() { return <svg width="10" height="10" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M8 1v14M2 4l12 8M2 12l12-8M5 2l3 2 3-2M5 14l3-2 3 2" stroke="currentColor" strokeWidth="1.2"/></svg>; }
function SunIcon() { return <svg width="10" height="10" viewBox="0 0 16 16" fill="none" aria-hidden="true"><circle cx="8" cy="8" r="3" stroke="currentColor"/><path d="M8 0v2m0 12v2M0 8h2m12 0h2M2 2l2 2m8 8 2 2M2 14l2-2m8-8 2-2" stroke="currentColor"/></svg>; }
