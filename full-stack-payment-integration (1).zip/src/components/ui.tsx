"use client";

import { useEffect, useId, useRef, type ReactNode } from "react";
import { X, QrCode, ShieldCheck, ArrowUpRight } from "lucide-react";
import type { PaymentMethod } from "@/lib/venue";

export function Logo({ light = false }: { light?: boolean }) {
  return <span className={`logo ${light ? "logo-light" : ""}`}><span>Smash</span><span>Court</span></span>;
}
export function PickleballIcon({ size = 64, className = "" }: { size?: number; className?: string }) {
  const id = useId();
  return <svg width={size} height={size} className={className} viewBox="0 0 72 72" fill="none" aria-hidden="true">
    <defs><linearGradient id={`${id}-paddle`} x1="23" y1="12" x2="60" y2="52" gradientUnits="userSpaceOnUse"><stop stopColor="#F13D9F"/><stop offset="1" stopColor="#B72283"/></linearGradient><linearGradient id={`${id}-ball`} x1="31" y1="4" x2="42" y2="16" gradientUnits="userSpaceOnUse"><stop stopColor="#F2EFF4"/><stop offset="1" stopColor="#C7C4CD"/></linearGradient></defs>
    <path d="m30 46-14 15" stroke="#E995A5" strokeWidth="10" strokeLinecap="round"/><path d="m28 49-10 11" stroke="#F6B7BE" strokeWidth="5" strokeLinecap="round"/>
    <path d="M57 19c11 11 10 24-1 32-10 8-23 5-32-4-9-9-8-22 1-30 10-9 23-8 32 2Z" fill={`url(#${id}-paddle)`}/>
    <path d="M24 25c4-7 12-11 20-9" stroke="#FF77BC" strokeOpacity=".45" strokeWidth="2" strokeLinecap="round"/><circle cx="37" cy="10" r="6.5" fill={`url(#${id}-ball)`}/>
  </svg>;
}
export function RacketIcon({ size = 24 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden="true"><g transform="rotate(38 16 16)"><rect x="5" y="2" width="22" height="23" rx="10.5" stroke="currentColor" strokeWidth="1.8"/><path d="M13 25v5a3 3 0 0 0 6 0v-5" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/><path d="M11 24h10" stroke="currentColor" strokeWidth="1.5"/></g></svg>;
}
export function CourtArt() {
  return <svg className="court-art" viewBox="0 0 560 230" fill="none" aria-hidden="true"><defs><linearGradient id="courtFade" x1="0" y1="0" x2="560" y2="230" gradientUnits="userSpaceOnUse"><stop stopColor="#D4ED83" stopOpacity=".04"/><stop offset="1" stopColor="#D4ED83" stopOpacity=".4"/></linearGradient></defs><g transform="translate(100 12) rotate(-16 200 100)" stroke="url(#courtFade)" strokeWidth="1.5"><rect x="20" y="10" width="350" height="186" rx="2"/><path d="M76 10v186M314 10v186M20 103h56m238 0h56"/><path d="M195 0v207" strokeDasharray="4 4"/><rect x="190" y="0" width="3" height="8" fill="#9AB773"/><rect x="197" y="199" width="3" height="8" fill="#9AB773"/></g><g transform="translate(408 75)"><circle r="30" fill="#C7EF70"/><g fill="#234A32"><circle cx="-12" cy="-14" r="4"/><circle cx="5" cy="-18" r="4"/><circle cx="19" cy="-6" r="4"/><circle cx="-20" cy="2" r="4"/><circle cx="-3" cy="0" r="4"/><circle cx="11" cy="13" r="4"/><circle cx="-8" cy="18" r="4"/></g></g><circle cx="100" cy="170" r="5" fill="#C7EF70" fillOpacity=".6"/><circle cx="489" cy="54" r="3" fill="#C7EF70" fillOpacity=".4"/></svg>;
}
export function PaymentMark({ method, compact = false }: { method: PaymentMethod; compact?: boolean }) {
  return <span className={`payment-mark payment-${method} ${compact ? "compact" : ""}`} aria-label={method === "maribank" ? "MariBank Mastercard" : method === "gotyme" ? "GoTyme Visa" : method}>
    {method === "maribank" && <><span className="mari-symbol">m</span><span>MariBank</span></>}
    {method === "gotyme" && <><span className="gotyme-go">go</span><span>tyme</span></>}
    {method === "card" && <><span className="visa-word">VISA</span><span className="mastercard-symbol"><i/><i/></span><span className="card-more">+ more</span></>}
    {method === "gcash" && <><span className="gcash-symbol">G</span><span>GCash</span></>}
    {method === "maya" && <><span>maya</span><span className="maya-dot"/></>}
    {method === "qrph" && <><QrCode size={20}/><span>QR Ph</span></>}
  </span>;
}
export function Modal({ title, eyebrow, children, onClose, wide = false }: { title: string; eyebrow?: string; children: ReactNode; onClose: () => void; wide?: boolean }) {
  const titleId = useId();
  const panel = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  useEffect(() => { closeRef.current = onClose; }, [onClose]);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const focusable = () => Array.from(panel.current?.querySelectorAll<HTMLElement>('button:not([disabled]), a[href], input:not([disabled]), select, textarea, [tabindex="0"]') || []);
    const timer = setTimeout(() => (panel.current?.querySelector<HTMLElement>("[data-autofocus]") || focusable()[0])?.focus(), 50);
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeRef.current();
      if (event.key === "Tab") {
        const items = focusable(); const first = items[0]; const last = items[items.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      }
    };
    document.addEventListener("keydown", onKey);
    return () => { clearTimeout(timer); document.body.style.overflow = overflow; document.removeEventListener("keydown", onKey); previous?.focus(); };
  }, []);
  return <div className="modal-overlay" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><div ref={panel} className={`modal-panel ${wide ? "modal-wide" : ""}`} role="dialog" aria-modal="true" aria-labelledby={titleId}><div className="modal-heading"><div>{eyebrow && <p className="eyebrow">{eyebrow}</p>}<h2 id={titleId}>{title}</h2></div><button className="icon-button close-button" onClick={onClose} aria-label="Close dialog"><X size={21}/></button></div>{children}</div></div>;
}
export function SecureNote({ demo = true }: { demo?: boolean }) { return <p className="secure-note"><ShieldCheck size={14}/>{demo ? "Demo checkout · No real money will be charged" : "Secure hosted checkout · Card details stay with PayMongo"}</p>; }
export function TextLink({ children, onClick }: { children: ReactNode; onClick: () => void }) { return <button className="text-link" onClick={onClick}>{children}<ArrowUpRight size={15}/></button>; }
