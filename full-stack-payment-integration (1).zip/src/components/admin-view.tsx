"use client";

import { useCallback, useEffect, useState } from "react";
import { CalendarCheck2, CircleCheck, CreditCard, LoaderCircle, LogOut, RefreshCw, ShieldCheck, ArrowRight } from "lucide-react";
import { apiFetch } from "@/lib/api";
import { dateLabel, peso, timeRange } from "@/lib/venue";

type Overview = { stats: { total: number; confirmed: number; liveRevenue: number; courts: number }; bookings: { id: string; reference: string; courtName: string; date: string; startHour: number; duration: number; amount: number; status: string; paymentMode: string }[] };
export function AdminView({ onBrowse, onLogout }: { onBrowse: () => void; onLogout: () => Promise<void> }) {
  const [data, setData] = useState<Overview | null>(null);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState("");
  const load = useCallback(async () => {
    setBusy(true); setError("");
    try { setData(await apiFetch<Overview>("/api/admin/overview")); }
    catch (error) { setError((error as Error).message); }
    finally { setBusy(false); }
  }, []);
  useEffect(() => {
    let active = true;
    apiFetch<Overview>("/api/admin/overview")
      .then((result) => { if (active) setData(result); })
      .catch((error: Error) => { if (active) setError(error.message); })
      .finally(() => { if (active) setBusy(false); });
    return () => { active = false; };
  }, []);
  return <section className="secondary-view admin-view"><div className="page-heading"><div><p className="eyebrow">SMASHCOURT MANAGEMENT</p><h1>Club overview<span>.</span></h1><p>A clear view of your pickleball court reservations.</p></div><button className="button outline" onClick={onLogout}><LogOut size={16}/>Sign out</button></div>
    <div className="admin-toolbar"><span><ShieldCheck size={16}/>Authorized administrator</span><button className="button outline small" disabled={busy} onClick={() => void load()}><RefreshCw size={14} className={busy ? "spin" : ""}/>Refresh overview</button></div>
    {error && <p className="form-error" role="alert">{error}</p>}
    {data ? <><div className="admin-stat-grid">{[{ label: "Total reservations", value: data.stats.total, icon: CalendarCheck2 }, { label: "Confirmed bookings", value: data.stats.confirmed, icon: CircleCheck }, { label: "Verified live revenue", value: peso(data.stats.liveRevenue), icon: CreditCard }, { label: "Pickleball courts", value: data.stats.courts, icon: ShieldCheck }].map(({ label, value, icon: Icon }) => <article key={label}><Icon size={21}/><span>{label}</span><strong>{value}</strong></article>)}</div><div className="admin-table-heading"><h2>Recent reservations</h2><button className="text-link" onClick={onBrowse}>View courts<ArrowRight size={15}/></button></div><div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Reference</th><th>Court</th><th>Schedule</th><th>Amount</th><th>Mode</th><th>Status</th></tr></thead><tbody>{data.bookings.map((booking) => <tr key={booking.id}><td>{booking.reference}</td><td>{booking.courtName}</td><td>{dateLabel(booking.date)}<small>{timeRange(booking.startHour, booking.duration)}</small></td><td>{peso(booking.amount)}</td><td>{booking.paymentMode}</td><td><span className={`status-pill ${booking.status}`}>{booking.status}</span></td></tr>)}</tbody></table>{!data.bookings.length && <div className="loading-state">No reservations yet. Your club’s next great game is waiting.</div>}</div><p className="history-note"><ShieldCheck size={17}/>Read-only overview. Demo bookings are excluded from live revenue. Refunds are handled through the payment provider.</p></> : busy ? <div className="loading-state"><LoaderCircle className="spin" size={20}/>Loading club overview…</div> : null}
  </section>;
}
