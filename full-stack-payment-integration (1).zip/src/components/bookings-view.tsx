"use client";

import { useState } from "react";
import { ArrowRight, Bell, CalendarDays, Check, CircleCheck, Clock3, CreditCard, Info, LoaderCircle, MapPin, RefreshCw, ReceiptText, ShieldCheck, X } from "lucide-react";
import { Modal, RacketIcon } from "@/components/ui";
import { apiFetch } from "@/lib/api";
import { bookingStart, dateLabel, paymentLabels, peso, timeRange, playerContact, type Booking, type PaymentMethod, type Player } from "@/lib/venue";

type ViewProps = {
  bookings: Booking[]; now: number; loading: boolean; player: Player | null; onRefresh: () => Promise<void>;
  onBook: () => void; onSignIn: () => void; onPay: (booking: Booking) => Promise<void>; notify: (message: string) => void;
};
const statusLabels: Record<string, string> = { confirmed: "Confirmed", pending: "Awaiting payment", cancelled: "Cancelled", expired: "Hold expired", refunded: "Demo refunded" };

export function BookingsView({ bookings, now, loading, player, onRefresh, onBook, onSignIn, onPay, notify }: ViewProps) {
  const [filter, setFilter] = useState("upcoming");
  const [receipt, setReceipt] = useState<Booking | null>(null);
  const [cancelTarget, setCancelTarget] = useState<Booking | null>(null);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const filtered = bookings.filter((booking) => {
    if (["cancelled", "refunded", "expired"].includes(booking.status)) return filter === "cancelled";
    return bookingStart(booking) + booking.duration * 3600000 > now ? filter === "upcoming" : filter === "past";
  });
  async function cancel() {
    if (!cancelTarget) return;
    setBusy(cancelTarget.id); setError("");
    try {
      await apiFetch(`/api/bookings/${cancelTarget.id}`, { method: "DELETE" });
      await onRefresh(); setCancelTarget(null);
      notify("Booking cancelled. Your court has been released.");
    } catch (error) { setError((error as Error).message); }
    finally { setBusy(""); }
  }
  async function sync(booking: Booking) {
    setBusy(booking.id);
    try { await apiFetch(`/api/bookings/${booking.id}/sync`, { method: "POST" }); await onRefresh(); notify("Booking status is up to date."); }
    catch (error) { notify((error as Error).message); }
    finally { setBusy(""); }
  }
  return <section className="secondary-view">
    <div className="page-heading"><div><p className="eyebrow">GOOD GAMES AHEAD</p><h1>My bookings<span>.</span></h1><p>Your matches, all in one place.</p></div><button className="button primary" onClick={onBook}>Book a court<ArrowRight size={17}/></button></div>
    {!player ? <div className="empty-state"><span className="empty-icon"><ReceiptText size={34}/></span><h2>Your next match belongs here.</h2><p>Sign in to see your reservations, download receipts, and manage your upcoming games.</p><button className="button primary" onClick={onSignIn}>Sign in to your account<ArrowRight size={17}/></button></div> : <>
      <div className="history-toolbar"><div className="history-tabs">{["upcoming", "past", "cancelled"].map((tab) => <button key={tab} className={filter === tab ? "active" : ""} onClick={() => setFilter(tab)}>{tab === "cancelled" ? "Cancelled & expired" : tab.charAt(0).toUpperCase() + tab.slice(1)}</button>)}</div><button className="icon-button" title="Refresh bookings" aria-label="Refresh bookings" onClick={async () => { setBusy("refresh"); try { await onRefresh(); } finally { setBusy(""); } }}><RefreshCw size={17} className={busy === "refresh" ? "spin" : ""}/></button></div>
      {loading && !bookings.length ? <div className="loading-state"><LoaderCircle className="spin"/>Loading your bookings…</div> : filtered.length === 0 ? <div className="empty-state"><span className="empty-icon"><RacketIcon size={40}/></span><h2>{filter === "upcoming" ? "The court is calling." : filter === "past" ? "Your story starts on court." : "All good on this side."}</h2><p>{filter === "upcoming" ? "No upcoming matches yet. Grab a court, invite your people, and make a game of it." : filter === "past" ? "Your completed games will appear here after you play." : "No cancelled or expired reservations to show."}</p><button className="button primary" onClick={onBook}>Find my court<ArrowRight size={17}/></button></div> : <div className="booking-list">{filtered.map((booking) => {
        const canCancel = (booking.status === "pending" || (booking.status === "confirmed" && booking.paymentMode === "demo")) && bookingStart(booking) > now + 2 * 3600000;
        return <article className="booking-card" key={booking.id}>
          <div className="booking-card-top"><div className="booking-date-tile"><span>{dateLabel(booking.date, { month: "short" })}</span><strong>{dateLabel(booking.date, { day: "numeric" })}</strong><small>{dateLabel(booking.date, { weekday: "short" })}</small></div><div className="booking-card-title"><span className="eyebrow">{booking.reference}</span><h2>{booking.courtName}</h2><p><MapPin size={14}/>SmashCourt Club</p></div><span className={`status-pill ${booking.status}`}>{booking.status === "confirmed" && <Check size={12}/>} {statusLabels[booking.status] || booking.status}</span></div>
          <div className="booking-card-details"><span><Clock3 size={16}/>{timeRange(booking.startHour, booking.duration)}</span><span><CreditCard size={16}/>{paymentLabels[booking.paymentMethod as PaymentMethod] || booking.paymentMethod}</span><strong>{peso(booking.amount)}</strong></div>
          <div className="booking-card-bottom"><span className="booking-mode">{booking.paymentMode === "demo" ? "Demo booking · No real charge" : "Paid through PayMongo"}</span><div className="booking-actions">{canCancel && <button className="button subtle small" onClick={() => { setCancelTarget(booking); setError(""); }}>Cancel booking</button>}{booking.status === "pending" && booking.paymentMode === "live" && <button className="button subtle small" disabled={Boolean(busy)} onClick={() => sync(booking)}><RefreshCw size={14} className={busy === booking.id ? "spin" : ""}/>Check status</button>}{booking.status === "pending" && bookingStart(booking) > now && booking.expiresAt > new Date(now).toISOString() && <button className="button primary small" disabled={Boolean(busy)} onClick={async () => { setBusy(booking.id); await onPay(booking); setBusy(""); }}>{busy === booking.id ? <LoaderCircle size={14} className="spin"/> : <CreditCard size={14}/>} {booking.checkoutUrl ? "Resume checkout" : "Complete booking"}</button>}{booking.status === "confirmed" && <a className="button subtle small" href={`/api/bookings/${booking.id}/calendar`}><CalendarDays size={14}/>Add to calendar</a>}<button className="button outline small" onClick={() => setReceipt(booking)}><ReceiptText size={14}/>Receipt</button></div></div>
        </article>;
      })}</div>}
      <div className="history-note"><ShieldCheck size={18}/><p>Plans change. Cancel online up to 2 hours before your game. Paid live bookings need club-assisted refunds.</p></div>
    </>}
    {receipt && <Modal title="Your booking receipt." eyebrow={receipt.reference} onClose={() => setReceipt(null)}><div className="receipt-brand"><RacketIcon size={30}/><span>SmashCourt Club</span><span className={`status-pill ${receipt.status}`}>{statusLabels[receipt.status]}</span></div><div className="receipt-lines"><div><span>Player</span><strong>{player?.name}</strong></div><div><span>Court</span><strong>{receipt.courtName}</strong></div><div><span>Date</span><strong>{dateLabel(receipt.date, { month: "long", day: "numeric", year: "numeric" })}</strong></div><div><span>Time</span><strong>{timeRange(receipt.startHour, receipt.duration)}</strong></div><div><span>Duration</span><strong>{receipt.duration} {receipt.duration === 1 ? "hour" : "hours"}</strong></div><div><span>Payment method</span><strong>{paymentLabels[receipt.paymentMethod as PaymentMethod]}</strong></div><div><span>Payment status</span><strong>{receipt.status === "confirmed" ? receipt.paymentMode === "demo" ? "Demo paid" : "Paid" : receipt.status === "refunded" ? "Demo refunded" : statusLabels[receipt.status]}</strong></div><div className="receipt-total"><span>Total</span><strong>{peso(receipt.amount)}</strong></div></div><div className="inline-notice"><Info size={18}/><span>{receipt.paymentMode === "demo" ? "Demo receipt only. No real payment was collected. This does not represent a physical venue reservation." : "Keep this reference for your records. Payment processing and refunds are handled through PayMongo."}</span></div>{receipt.status === "confirmed" && <a className="button primary full-width" href={`/api/bookings/${receipt.id}/calendar`}><CalendarDays size={17}/>Add to my calendar</a>}<button className="button ghost full-width" onClick={() => setReceipt(null)}>Back to my bookings</button></Modal>}
    {cancelTarget && <Modal title="Need a rain check?" eyebrow="CANCEL YOUR BOOKING" onClose={() => { if (!busy) setCancelTarget(null); }}><p className="modal-intro">Release <strong>{cancelTarget.courtName}</strong> on {dateLabel(cancelTarget.date)} at {timeRange(cancelTarget.startHour, cancelTarget.duration)}?{cancelTarget.paymentMode === "demo" && cancelTarget.status === "confirmed" ? " Your demo payment will be marked refunded." : ""}</p><div className="inline-notice"><CalendarDays size={20}/><span>This frees the court for another player. You can always book again if your plans change.</span></div>{error && <p className="form-error" role="alert">{error}</p>}<div className="dialog-actions"><button className="button outline" disabled={Boolean(busy)} onClick={() => setCancelTarget(null)}>Keep my booking</button><button className="button danger" disabled={Boolean(busy)} onClick={cancel}>{busy ? <LoaderCircle size={17} className="spin"/> : <X size={17}/>}Cancel booking</button></div></Modal>}
  </section>;
}

export function AlertsView({ bookings, readIds, onRead, onBookings, onBook }: { bookings: Booking[]; readIds: string[]; onRead: (ids: string[]) => void; onBookings: () => void; onBook: () => void }) {
  const notifications = [
    ...bookings.slice(0, 12).map((booking) => ({ id: booking.id, title: booking.status === "confirmed" ? `${booking.courtName} is all yours.` : booking.status === "pending" ? "Your court is on hold." : `Booking ${booking.status}.`, text: `${dateLabel(booking.date)} · ${timeRange(booking.startHour, booking.duration)} · ${booking.reference}`, type: booking.status === "confirmed" ? "success" : "info", action: true })),
    { id: "welcome", title: "Welcome to your home court.", text: "Four courts. Endless good games. Find a slot and bring your favorite pickleball partner.", type: "welcome", action: false },
    { id: "payments", title: liveTitle(bookings), text: "MariBank, GoTyme, cards, and e-wallets. Choose your payment method when you book.", type: "payment", action: false },
  ];
  const unread = notifications.filter((item) => !readIds.includes(item.id));
  return <section className="secondary-view alerts-view"><div className="page-heading"><div><p className="eyebrow">A LITTLE HEADS-UP</p><h1>Your alerts<span>.</span></h1><p>Booking updates and things worth knowing.</p></div><button className="button outline" disabled={!unread.length} onClick={() => onRead([...new Set([...readIds, ...notifications.map((item) => item.id)])])}><Check size={17}/>Mark all as read</button></div><div className="alerts-summary"><Bell size={18}/>{unread.length ? `${unread.length} unread ${unread.length === 1 ? "update" : "updates"}` : "You’re all caught up. Time to play."}</div><div className="notification-list">{notifications.map((item) => <button key={item.id} className={`notification-card ${readIds.includes(item.id) ? "read" : ""}`} onClick={() => { onRead([...readIds, item.id]); if (item.action) onBookings(); else onBook(); }}><span className={`notification-icon ${item.type}`}>{item.type === "success" ? <CircleCheck size={23}/> : item.type === "payment" ? <CreditCard size={23}/> : item.type === "welcome" ? <RacketIcon size={26}/> : <Clock3 size={23}/>}</span><span className="notification-copy"><strong>{item.title}</strong><span>{item.text}</span><small>{item.action ? "View booking" : "Explore SmashCourt"}<ArrowRight size={13}/></small></span>{!readIds.includes(item.id) && <span className="unread-dot"/>}</button>)}</div></section>;
}
function liveTitle(bookings: Booking[]) { return bookings.some((booking) => booking.paymentMode === "live") ? "Your favorite ways to pay." : "Easy payments, made for you."; }
