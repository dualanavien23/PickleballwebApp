import { randomBytes, createHash, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { cookies } from "next/headers";
import { NextRequest, NextResponse } from "next/server";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { AppError } from "@/lib/api";

const scrypt = promisify(scryptCallback);
export const SESSION_COOKIE = "smashcourt_session";
export const playerColumns = { id: users.id, name: users.name, email: users.email, phone: users.phone, role: users.role, preferredPayment: users.preferredPayment };
const digest = (value: string) => createHash("sha256").update(value).digest("hex");
export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const hash = await scrypt(password, salt, 64) as Buffer;
  return `${salt}:${hash.toString("hex")}`;
}
export async function verifyPassword(password: string, stored: string) {
  const [salt, expected] = stored.split(":");
  if (!salt || !expected) return false;
  const actual = await scrypt(password, salt, 64) as Buffer;
  const expectedBuffer = Buffer.from(expected, "hex");
  return actual.length === expectedBuffer.length && timingSafeEqual(actual, expectedBuffer);
}
export async function getPlayer() {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  if (!token || token.length !== 64) return null;
  const [player] = await db.select(playerColumns).from(sessions).innerJoin(users, eq(sessions.userId, users.id))
    .where(and(eq(sessions.tokenHash, digest(token)), gt(sessions.expiresAt, new Date()))).limit(1);
  return player ?? null;
}
export async function requirePlayer() {
  const player = await getPlayer();
  if (!player) throw new AppError("Please sign in to continue.", 401);
  return player;
}
export async function requireAdmin() {
  const player = await requirePlayer();
  if (player.role !== "admin") throw new AppError("This area is restricted to authorized club administrators.", 403);
  return player;
}
export async function createSession(userId: string, response: NextResponse, request: NextRequest, role = "player") {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + (role === "admin" ? 8 * 3600000 : 7 * 86400000));
  await db.insert(sessions).values({ tokenHash: digest(token), userId, expiresAt });
  response.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true, sameSite: "lax", path: "/", expires: expiresAt,
    secure: request.headers.get("x-forwarded-proto") === "https" || request.nextUrl.protocol === "https:",
  });
}

export async function destroySession() {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  if (token) await db.delete(sessions).where(eq(sessions.tokenHash, digest(token)));
}
