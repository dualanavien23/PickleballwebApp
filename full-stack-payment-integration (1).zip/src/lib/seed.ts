import { db } from "@/db";
import { courts, courtBlocks } from "@/db/schema";
import { sql } from "drizzle-orm";
import { manilaDate } from "@/lib/venue";

export const venueCourts = [
  { id: "court-a", name: "Court A", kind: "Indoor", description: "Air-conditioned · Pro court surface", price: 350, capacity: 4, popular: true, sortOrder: 0 },
  { id: "court-b", name: "Court B", kind: "Indoor", description: "Air-conditioned · Pro court surface", price: 350, capacity: 4, popular: false, sortOrder: 1 },
  { id: "court-c", name: "Court C", kind: "Outdoor", description: "Open air · Dedicated pickleball", price: 250, capacity: 4, popular: false, sortOrder: 2 },
  { id: "court-d", name: "Court D", kind: "Outdoor", description: "Open air · Dedicated pickleball", price: 250, capacity: 4, popular: false, sortOrder: 3 },
];
let seedPromise: Promise<void> | undefined;
export function ensureVenueSeed() {
  if (!seedPromise) {
    seedPromise = (async () => {
      await db.insert(courts).values(venueCourts).onConflictDoUpdate({ target: courts.id, set: { description: sql`excluded.description` } });
      const hours: Record<string, number[]> = { "court-a": [7, 16, 19], "court-b": [6, 9, 13, 18], "court-c": [8, 12, 17], "court-d": [7, 11, 15, 20] };
      const blocks = Array.from({ length: 7 }, (_, day) => manilaDate(day)).flatMap((date, day) =>
        venueCourts.flatMap((court) => hours[court.id].map((base) => {
          const hour = 6 + ((base - 6 + day) % 15);
          return { id: `${court.id}:${date}:${hour}`, courtId: court.id, date, hour, reason: "Scheduled court maintenance" };
        }))
      );
      await db.insert(courtBlocks).values(blocks).onConflictDoNothing();
    })().catch((error) => { seedPromise = undefined; throw error; });
  }
  return seedPromise;
}
