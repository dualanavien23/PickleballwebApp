import { createHmac, timingSafeEqual } from "node:crypto";
import { AppError } from "@/lib/api";
import type { PaymentMethod } from "@/lib/venue";

export const paymentsLive = () => Boolean(process.env.PAYMONGO_SECRET_KEY && process.env.PAYMONGO_WEBHOOK_SECRET && process.env.APP_URL);
export const livePaymentMethods = () => (process.env.PAYMONGO_PAYMENT_METHODS || "card,gcash,paymaya").split(",").map((method) => method.trim());
export function providerMethods(method: PaymentMethod) {
  return method === "gcash" ? ["gcash"] : method === "maya" ? ["paymaya"] : method === "qrph" ? ["qrph"] : ["card"];
}
export type CheckoutResource = {
  id: string;
  attributes: {
    checkout_url: string;
    status?: string;
    reference_number: string;
    metadata?: Record<string, string>;
    livemode?: boolean;
    payments?: { id: string; attributes: { amount: number; currency: string; status: string; net_amount?: number; source?: { type: string } } }[];
  };
};
export async function paymongo<T>(path: string, method = "GET", body?: unknown, idempotencyKey?: string): Promise<T> {
  const key = process.env.PAYMONGO_SECRET_KEY;
  if (!key) throw new AppError("Live payments are not configured. Demo bookings are available.", 503);
  let response: Response;
  try {
    response = await fetch(`https://api.paymongo.com${path}`, {
      method, cache: "no-store", signal: AbortSignal.timeout(15000),
      headers: { Authorization: `Basic ${Buffer.from(`${key}:`).toString("base64")}`, "Content-Type": "application/json", ...(idempotencyKey ? { "Idempotency-Key": idempotencyKey } : {}) },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
  } catch { throw new AppError("The payment provider is taking too long. Please check My bookings before trying again.", 504); }
  const result = await response.json().catch(() => null);
  if (!response.ok) {
    console.error("PayMongo request failed", { path, status: response.status, code: result?.errors?.[0]?.code });
    throw new AppError("The payment provider couldn’t complete this request. Please try again or choose another method.", 502);
  }
  return result.data as T;
}
export async function createCheckout(booking: { id: string; reference: string; courtId: string; amount: number; date: string; paymentMethod: PaymentMethod }, playerName: string, email: string | null) {
  const methods = providerMethods(booking.paymentMethod);
  if (methods.some((method) => !livePaymentMethods().includes(method))) throw new AppError("This payment method is not enabled for live checkout. Please choose another method.", 400);
  const origin = process.env.APP_URL!.replace(/\/$/, "");
  const resource = await paymongo<CheckoutResource>("/v2/checkout_sessions", "POST", {
    data: { attributes: {
      line_items: [{ name: `SmashCourt · ${booking.courtId.replace("court-", "Court ").toUpperCase()} · ${booking.date}`, amount: booking.amount * 100, currency: "PHP", quantity: 1 }],
      payment_method_types: methods,
      pass_on_fees: false,
      reference_number: booking.reference,
      description: `Pickleball court reservation ${booking.reference}`,
      billing: { name: playerName, ...(email ? { email } : {}) },
      send_email_receipt: Boolean(email),
      success_url: `${origin}/?booking=${booking.id}&payment=return`,
      cancel_url: `${origin}/?booking=${booking.id}&payment=cancelled`,
      metadata: { booking_id: booking.id, reference: booking.reference },
    } },
  }, booking.id);
  const url = new URL(resource.attributes.checkout_url);
  if (url.protocol !== "https:" || !url.hostname.endsWith("paymongo.com")) throw new AppError("The provider returned an invalid checkout address.", 502);
  return resource;
}
export async function retrieveCheckout(id: string) { return paymongo<CheckoutResource>(`/v1/checkout_sessions/${encodeURIComponent(id)}`); }
export async function expireCheckout(id: string) { return paymongo<CheckoutResource>(`/v1/checkout_sessions/${encodeURIComponent(id)}/expire`, "POST"); }
export function verifyWebhook(raw: string, signature: string, secret: string) {
  try {
    const parts = Object.fromEntries(signature.split(",").map((part) => { const at = part.indexOf("="); return [part.slice(0, at), part.slice(at + 1)]; }));
    const timestamp = Number(parts.t);
    if (!Number.isFinite(timestamp) || Math.abs(Date.now() / 1000 - timestamp) > 300) return false;
    const expected = createHmac("sha256", secret).update(`${parts.t}.${raw}`).digest("hex");
    return [parts.te, parts.li].some((value) => {
      if (!value || !/^[a-f0-9]{64}$/i.test(value)) return false;
      return timingSafeEqual(Buffer.from(expected, "hex"), Buffer.from(value, "hex"));
    });
  } catch { return false; }
}
