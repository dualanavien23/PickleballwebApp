import { z } from "zod";

export type Identity = { kind: "email"; value: string } | { kind: "phone"; value: string };
export function normalizeIdentifier(raw: string): Identity | null {
  const value = raw.trim();
  if (value.includes("@")) {
    const email = value.toLowerCase();
    return z.email().max(254).safeParse(email).success ? { kind: "email", value: email } : null;
  }
  const compact = value.replace(/[\s()\-]/g, "");
  const phone = compact.startsWith("09") && compact.length === 11 ? `+63${compact.slice(1)}` : compact.startsWith("+639") && compact.length === 13 ? compact : null;
  return phone && /^\+639\d{9}$/.test(phone) ? { kind: "phone", value: phone } : null;
}
export const identifierSchema = z.string().trim().min(1, "Enter your mobile number or email.").max(254).transform((value, context) => {
  const identity = normalizeIdentifier(value);
  if (!identity) { context.addIssue({ code: "custom", message: "Enter a valid email or Philippine mobile number, such as 09171234567." }); return z.NEVER; }
  return identity;
});
