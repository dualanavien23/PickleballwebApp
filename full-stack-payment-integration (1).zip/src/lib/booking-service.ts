import { randomBytes } from "node:crypto";
import { and, asc, desc, eq, inArray, lt, lte } from "drizzle-orm";
import { db } from "@/db";
import { bookings, bookingSlots, courtBlocks, courts, payments, users } from "@/db/schema";
import { AppError } from "@/lib/api";
import { createCheckout, expireCheckout, paymentsLive, providerMethods, livePaymentMethods, retrieveCheckout, type CheckoutResource } from "@/lib/payments";
import { manilaDate, manilaHour, validDate, type PaymentMethod, type Player } from "@/lib/venue";

type Transaction = Parameters<Parameters<typeof db.transaction>[0]>[0];
type BookingRow = typeof bookings.$inferSelect;
export async function listBookings(userId: string) {
  const rows = await db.select({ booking: bookings, courtName: courts.name }).from(bookings)
    .innerJoin(courts, eq(bookings.courtId, courts.id)).where(eq(bookings.userId, userId)).orderBy(desc(bookings.createdAt));
  return rows.map(({ booking, courtName }) => ({ ...booking, courtName }));
}
export async function findBooking(id: string, userId?: string) {
  const [row] = await db.select({ booking: bookings, courtName: courts.name }).from(bookings)
    .innerJoin(courts, eq(bookings.courtId, courts.id))
    .where(and(eq(bookings.id, id), ...(userId ? [eq(bookings.userId, userId)] : []))).limit(1);
  if (!row) throw new AppError("We couldn’t find that booking.", 404);
  return { ...row.booking, courtName: row.courtName };
}
export function expectedLiveMode() { return process.env.PAYMONGO_SECRET_KEY?.startsWith("sk_live_") ?? false; }
export function getPaidPayment(resource: CheckoutResource, booking: BookingRow, live: boolean) {
  if (resource.id !== booking.checkoutId && booking.checkoutId !== null) throw new AppError("Checkout reference mismatch.", 400);
  if (resource.attributes.reference_number !== booking.reference || resource.attributes.metadata?.booking_id !== booking.id || live !== expectedLiveMode()) throw new AppError("Payment verification failed.", 400);
  const payment = resource.attributes.payments?.find((item) => item.attributes.status === "paid");
  if (!payment) return null;
  if (payment.attributes.currency !== "PHP" || payment.attributes.amount !== booking.amount * 100) throw new AppError("Payment amount does not match this reservation.", 400);
  return payment;
}
export async function recordPayment(tx: Transaction, booking: BookingRow, providerId: string, method: string, mode: string, checkoutId?: string) {
  if (booking.status === "confirmed") return;
  if (booking.status !== "pending") throw new AppError("A payment arrived for a closed booking. Manual reconciliation is required.", 409);
  await tx.insert(payments).values({ bookingId: booking.id, providerId, amount: booking.amount * 100, method, mode }).onConflictDoNothing();
  await tx.update(bookings).set({ status: "confirmed", paidAt: new Date(), ...(checkoutId && !booking.checkoutId ? { checkoutId } : {}) }).where(eq(bookings.id, booking.id));
}
export async function reconcileBooking(booking: BookingRow) {
  if (booking.paymentMode !== "live" || booking.status !== "pending" || !booking.checkoutId) return booking;
  const resource = await retrieveCheckout(booking.checkoutId);
  const paid = getPaidPayment(resource, booking, resource.attributes.livemode ?? false);
  if (!paid) return booking;
  await db.transaction(async (tx) => {
    const [current] = await tx.select().from(bookings).where(eq(bookings.id, booking.id)).for("update");
    await recordPayment(tx, current, paid.id, paid.attributes.source?.type || "card", expectedLiveMode() ? "live" : "test", resource.id);
  });
  return { ...booking, status: "confirmed", paidAt: new Date() };
}
export async function reconcileExpired() {
  const expired = await db.select().from(bookings).where(and(eq(bookings.status, "pending"), lte(bookings.expiresAt, new Date()))).limit(10);
  for (const booking of expired) {
    try {
      // A timed-out create request may still have created a provider checkout.
      // Never release that hold until its idempotent retry links the session.
      if (booking.paymentMode === "live" && !booking.checkoutId) continue;
      if (booking.paymentMode === "live" && booking.checkoutId) {
        const resource = await retrieveCheckout(booking.checkoutId);
        const paid = getPaidPayment(resource, booking, resource.attributes.livemode ?? false);
        if (paid) {
          await db.transaction(async (tx) => {
            const [current] = await tx.select().from(bookings).where(eq(bookings.id, booking.id)).for("update");
            await recordPayment(tx, current, paid.id, paid.attributes.source?.type || "card", expectedLiveMode() ? "live" : "test", resource.id);
          });
          continue;
        }
        if (resource.attributes.status !== "expired") await expireCheckout(booking.checkoutId);
      }
      await db.transaction(async (tx) => {
        const [current] = await tx.select().from(bookings).where(eq(bookings.id, booking.id)).for("update");
        if (current.status !== "pending") return;
        await tx.delete(bookingSlots).where(eq(bookingSlots.bookingId, booking.id));
        await tx.update(bookings).set({ status: "expired" }).where(eq(bookings.id, booking.id));
      });
    } catch { console.error("Pending checkout needs reconciliation", booking.id); }
  }
}
export async function createBooking(player: Player, input: { courtId: string; date: string; startHour: number; duration: number; paymentMethod: PaymentMethod }) {
  if (!validDate(input.date)) throw new AppError("Choose a date within the next seven days.");
  if (!Number.isInteger(input.startHour) || !Number.isInteger(input.duration) || input.startHour < 6 || input.duration < 1 || input.duration > 2 || input.startHour + input.duration > 22) throw new AppError("Choose one or two hours between 6 AM and 10 PM.");
  if (input.date === manilaDate() && input.startHour <= manilaHour()) throw new AppError("That time has passed. Please choose a later slot.");
  const live = paymentsLive();
  if (live && providerMethods(input.paymentMethod).some((method) => !livePaymentMethods().includes(method))) throw new AppError("That payment method isn’t enabled yet. Please choose another.");
  const requestedHours = Array.from({ length: input.duration }, (_, index) => input.startHour + index);
  const booking = await db.transaction(async (tx) => {
    const [court] = await tx.select().from(courts).where(eq(courts.id, input.courtId)).for("update");
    if (!court) throw new AppError("That court doesn’t exist.", 404);
    const [blocked, reserved] = await Promise.all([
      tx.select().from(courtBlocks).where(and(eq(courtBlocks.courtId, court.id), eq(courtBlocks.date, input.date), inArray(courtBlocks.hour, requestedHours))),
      tx.select().from(bookingSlots).where(and(eq(bookingSlots.courtId, court.id), eq(bookingSlots.date, input.date), inArray(bookingSlots.hour, requestedHours))),
    ]);
    if (blocked.length || reserved.length) throw new AppError("Someone just picked that slot. Please choose another time.", 409);
    const [created] = await tx.insert(bookings).values({
      reference: `SC-${randomBytes(5).toString("hex").toUpperCase()}`, userId: player.id, courtId: court.id,
      date: input.date, startHour: input.startHour, duration: input.duration, amount: court.price * input.duration,
      paymentMethod: input.paymentMethod, paymentMode: live ? "live" : "demo", expiresAt: new Date(Date.now() + 15 * 60000),
    }).returning();
    await tx.insert(bookingSlots).values(requestedHours.map((hour) => ({ bookingId: created.id, courtId: court.id, date: input.date, hour })));
    if (!live) await recordPayment(tx, created, `demo_${created.id}`, input.paymentMethod, "demo");
    return created;
  });
  let checkoutError: string | undefined;
  if (live) {
    try { await startCheckout(booking, player); }
    catch (error) { checkoutError = error instanceof AppError ? error.message : "Your slot is reserved. Retry checkout from My bookings."; }
  }
  return { booking: await findBooking(booking.id, player.id), checkoutError };
}
export async function startCheckout(booking: BookingRow, player: Pick<Player, "name" | "email">) {
  if (booking.status === "confirmed") return booking;
  if (booking.status !== "pending" || booking.expiresAt.getTime() <= Date.now()) throw new AppError("This hold has ended. Please select a new slot.", 409);
  if (new Date(`${booking.date}T${String(booking.startHour).padStart(2, "0")}:00:00+08:00`).getTime() <= Date.now()) throw new AppError("This time slot has already started. Please choose a later court.");
  if (booking.checkoutUrl) return booking;
  const resource = await createCheckout({ ...booking, paymentMethod: booking.paymentMethod as PaymentMethod }, player.name, player.email);
  const [updated] = await db.update(bookings).set({ checkoutId: resource.id, checkoutUrl: resource.attributes.checkout_url })
    .where(and(eq(bookings.id, booking.id), eq(bookings.status, "pending"))).returning();
  if (!updated) throw new AppError("This booking has changed. Refresh My bookings.", 409);
  return updated;
}
export async function demoPayment(id: string, userId: string) {
  return db.transaction(async (tx) => {
    const [booking] = await tx.select().from(bookings).where(and(eq(bookings.id, id), eq(bookings.userId, userId))).for("update");
    if (!booking) throw new AppError("Booking not found.", 404);
    if (booking.paymentMode !== "demo") throw new AppError("This booking must be paid through the secure payment provider.");
    if (booking.status === "confirmed") return booking;
    if (booking.status !== "pending" || booking.expiresAt.getTime() <= Date.now()) throw new AppError("This reservation is no longer payable.", 409);
    if (new Date(`${booking.date}T${String(booking.startHour).padStart(2, "0")}:00:00+08:00`).getTime() <= Date.now()) throw new AppError("This time slot has already started. Please choose a later court.");
    await recordPayment(tx, booking, `demo_${booking.id}`, booking.paymentMethod, "demo");
    return { ...booking, status: "confirmed", paidAt: new Date() };
  });
}
export async function cancelBooking(id: string, userId: string) {
  const [initial] = await db.select().from(bookings).where(and(eq(bookings.id, id), eq(bookings.userId, userId)));
  if (!initial) throw new AppError("Booking not found.", 404);
  if (["cancelled", "expired", "refunded"].includes(initial.status)) return initial;
  if (new Date(`${initial.date}T${String(initial.startHour).padStart(2, "0")}:00:00+08:00`).getTime() - Date.now() < 2 * 3600000) throw new AppError("Online cancellation closes two hours before play. Please contact the club.");
  if (initial.paymentMode === "live") {
    if (initial.status === "confirmed") throw new AppError("For a paid live booking, contact the club to request a cancellation and provider refund.");
    if (!initial.checkoutId) throw new AppError("This checkout is being reconciled. Retry checkout or contact the club before cancelling.");
    if (initial.checkoutId) {
      const resource = await retrieveCheckout(initial.checkoutId);
      const paid = getPaidPayment(resource, initial, resource.attributes.livemode ?? false);
      if (paid) { await reconcileBooking(initial); throw new AppError("Your payment has been confirmed. Contact the club for cancellation."); }
      if (resource.attributes.status !== "expired") await expireCheckout(initial.checkoutId);
    }
  }
  return db.transaction(async (tx) => {
    const [booking] = await tx.select().from(bookings).where(eq(bookings.id, id)).for("update");
    if (["cancelled", "expired", "refunded"].includes(booking.status)) return booking;
    if (booking.paymentMode === "live" && booking.status === "confirmed") throw new AppError("A live payment requires club-assisted cancellation.", 409);
    const status = booking.status === "confirmed" && booking.paymentMode === "demo" ? "refunded" : "cancelled";
    await tx.delete(bookingSlots).where(eq(bookingSlots.bookingId, id));
    if (status === "refunded") await tx.update(payments).set({ status: "refunded" }).where(eq(payments.bookingId, id));
    const [updated] = await tx.update(bookings).set({ status }).where(eq(bookings.id, id)).returning();
    return updated;
  });
}
export async function getAvailability(date: string) {
  const [blocks, reserved] = await Promise.all([
    db.select().from(courtBlocks).where(eq(courtBlocks.date, date)),
    db.select().from(bookingSlots).where(eq(bookingSlots.date, date)),
  ]);
  const unavailable: Record<string, number[]> = {};
  for (const slot of [...blocks, ...reserved]) (unavailable[slot.courtId] ??= []).push(slot.hour);
  return { date, unavailable, serverNow: Date.now(), past: date === manilaDate() ? Array.from({ length: Math.max(0, Math.min(16, manilaHour() - 5)) }, (_, index) => index + 6) : [] };
}
