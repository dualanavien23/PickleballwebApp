export const TIME_ZONE = "Asia/Manila";
export const OPEN_HOUR = 6;
export const CLOSE_HOUR = 22;
export const PAYMENT_METHODS = ["maribank", "gotyme", "card", "gcash", "maya", "qrph"] as const;
export type PaymentMethod = (typeof PAYMENT_METHODS)[number];
export const paymentLabels: Record<PaymentMethod, string> = {
  maribank: "MariBank card", gotyme: "GoTyme card", card: "Credit / debit card", gcash: "GCash", maya: "Maya", qrph: "QR Ph",
};
export const paymentDetails: Record<PaymentMethod, string> = {
  maribank: "Pay with your eligible MariBank Mastercard.",
  gotyme: "Pay with your eligible GoTyme Visa card.",
  card: "Visa, Mastercard, and other cards enabled by your provider.",
  gcash: "Approve your payment securely in GCash.",
  maya: "Approve your payment securely in Maya.",
  qrph: "Scan with a participating QR Ph bank or wallet.",
};
export type Court = { id: string; name: string; kind: string; description: string; price: number; capacity: number; popular: boolean; sortOrder: number };
export type Player = { id: string; name: string; email: string | null; phone: string | null; role: string; preferredPayment: string };
export function playerContact(player: Pick<Player, "email" | "phone">) { return player.email || player.phone || "Mobile player"; }
export type Booking = {
  id: string; reference: string; courtId: string; courtName: string; date: string; startHour: number;
  duration: number; amount: number; status: string; paymentMethod: string; paymentMode: string;
  checkoutUrl: string | null; expiresAt: string; createdAt: string; paidAt: string | null;
};
export type Availability = { date: string; unavailable: Record<string, number[]>; past: number[]; serverNow: number };
export function manilaDate(offset = 0) {
  const date = new Date(Date.now() + offset * 86400000);
  return new Intl.DateTimeFormat("en-CA", { timeZone: TIME_ZONE, year: "numeric", month: "2-digit", day: "2-digit" }).format(date);
}
export function manilaHour() {
  return Number(new Intl.DateTimeFormat("en-GB", { timeZone: TIME_ZONE, hour: "2-digit", hourCycle: "h23" }).format(new Date()));
}
export function dateLabel(date: string, options: Intl.DateTimeFormatOptions = { weekday: "short", month: "short", day: "numeric" }) {
  return new Intl.DateTimeFormat("en-PH", { ...options, timeZone: "UTC" }).format(new Date(`${date}T12:00:00Z`));
}
export function formatHour(hour: number) { return `${hour % 12 || 12}:00 ${hour >= 12 ? "PM" : "AM"}`; }
export function timeRange(hour: number, duration = 1) { return `${formatHour(hour)} – ${formatHour(hour + duration)}`; }
export function peso(amount: number) { return `₱${amount.toLocaleString("en-PH")}`; }
export function validDate(date: string) { return /^\d{4}-\d{2}-\d{2}$/.test(date) && date >= manilaDate() && date <= manilaDate(6); }
export function bookingStart(booking: Pick<Booking, "date" | "startHour">) { return new Date(`${booking.date}T${String(booking.startHour).padStart(2, "0")}:00:00+08:00`).getTime(); }
