import { NextRequest, NextResponse } from "next/server";
import { ZodError } from "zod";

export class AppError extends Error {
  constructor(message: string, public status = 400) { super(message); }
}
export function assertSameOrigin(request: NextRequest) {
  const origin = request.headers.get("origin");
  if (!origin) return;
  const allowed = [request.nextUrl.host, request.headers.get("host"), request.headers.get("x-forwarded-host")];
  try { if (!allowed.includes(new URL(origin).host)) throw new Error("origin"); }
  catch { throw new AppError("This request origin is not allowed.", 403); }
}
export async function readJson(request: NextRequest) {
  assertSameOrigin(request);
  const text = await request.text();
  if (text.length > 20000) throw new AppError("Request is too large.", 413);
  try { return JSON.parse(text); } catch { throw new AppError("Please send valid JSON."); }
}
export async function handleApi(action: () => Promise<Response>) {
  try { return await action(); }
  catch (error) {
    if (error instanceof AppError) return NextResponse.json({ error: error.message }, { status: error.status });
    if (error instanceof ZodError) return NextResponse.json({ error: error.issues[0]?.message || "Please check your details." }, { status: 400 });
    const pgError = error as { code?: string; cause?: { code?: string } };
    if (pgError.code === "23505" || pgError.cause?.code === "23505") return NextResponse.json({ error: "That slot or account is already taken. Please refresh and try again." }, { status: 409 });
    console.error("API request failed", error instanceof Error ? error.message : "Unknown error");
    return NextResponse.json({ error: "We couldn’t complete that request. Please try again." }, { status: 500 });
  }
}
export async function apiFetch<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, { ...options, cache: "no-store", headers: { "Content-Type": "application/json", ...options?.headers } });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Something went wrong. Please try again.");
  return data as T;
}
