import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { normalizeIdentifier } from "@/lib/identity";

export function adminConfigured() {
  const identity = normalizeIdentifier(process.env.ADMIN_EMAIL || "");
  return identity?.kind === "email" && (process.env.ADMIN_PASSWORD?.length || 0) >= 12;
}
let provisioning: Promise<void> | undefined;
export function ensureAdmin() {
  if (!adminConfigured()) return Promise.resolve();
  if (!provisioning) {
    provisioning = (async () => {
      const identity = normalizeIdentifier(process.env.ADMIN_EMAIL!);
      if (identity?.kind !== "email") return;
      const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, identity.value)).limit(1);
      if (existing) return; // Never reset an existing password or silently promote a player.
      await db.insert(users).values({ name: "Club Admin", email: identity.value, passwordHash: await hashPassword(process.env.ADMIN_PASSWORD!), role: "admin" }).onConflictDoNothing();
    })().catch((error) => { provisioning = undefined; throw error; });
  }
  return provisioning;
}
