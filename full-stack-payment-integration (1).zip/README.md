# SmashCourt

A complete pickleball-court reservation application built with Next.js App Router, PostgreSQL, and Drizzle ORM. The centered sign-in screen follows the supplied forest-green/lime reference, with a pink pickleball paddle, mobile/email access, guest browsing, and a permission-checked administrator option. Signed-in players can use responsive court cards, a calendar, booking history, and Philippine payment checkout.

## Run locally

1. Install dependencies with `npm install`.
2. Copy `.env.example` to `.env` and set `DATABASE_URL` to your PostgreSQL database.
3. Apply the schema with `npx drizzle-kit push`.
4. Start development with `npm run dev`.
5. Open http://localhost:3000.

The four courts and seven days of illustrative maintenance slots are seeded idempotently on the first request. All dates use Asia/Manila. The venue, prices, and maintenance schedule are sample data, not a claim about a real business.

## What works without payment credentials

- Continue as Guest to browse four pickleball courts and seven booking dates without an account.
- Sign in or register with a Philippine mobile number (09XXXXXXXXX) or email.
- Select one or two consecutive hours on one court.
- Create a player account or sign in with an email and password.
- Confirm a **demo booking** without card details or a real charge.
- See persistent booking history, receipts, and downloadable `.ics` calendar events.
- Cancel eligible demo bookings, reverse their demo payment, and release the slot.
- Edit a player name and preferred payment method.
- Read and dismiss booking alerts.

Demo mode is the default when the complete live-payment configuration is absent. Demo receipts are explicitly marked. No real court reservation or money transfer occurs in demo mode.

## Administrator access

There is no default or hardcoded administrator password. Set `ADMIN_EMAIL` to an unregistered club-owner email and `ADMIN_PASSWORD` to a strong secret of at least 12 characters, then restart the app. The admin account is provisioned on the first **Sign In as Admin** attempt. Sign in with those credentials to see the read-only club overview and recent reservations.

Existing account passwords are never overwritten, and registering an ordinary player never grants admin privileges. Admin API routes independently check the server-side role. Admin sessions expire after eight hours. Without owner configuration, the admin button explains that setup is required rather than pretending to grant access. Mobile sign-in normalizes Philippine numbers to +63 format; it does not send SMS OTPs.

## MariBank, GoTyme, cards, and wallets

This application uses **PayMongo Hosted Checkout**, not a fabricated direct-bank API.

- MariBank's eligible **Mastercard** cards use the `card` payment route.
- GoTyme's eligible **Visa** cards use the `card` payment route.
- Other Visa/Mastercard cards use the same route when enabled by the merchant and authorized by the issuer.
- GCash uses `gcash`; Maya uses `paymaya`; participating bank/wallet QR payments use `qrph`.
- JCB, Amex, Discover, Diners, and other networks are **not guaranteed**. Acceptance depends on the provider's current merchant capabilities and the issuer. There is no honest promise that every existing card is accepted.
- MariBank/GoTyme bank transfers, account logins, PINs, and direct debit are not implemented.

Card details are entered only on PayMongo's HTTPS hosted checkout. SmashCourt never collects or stores card numbers, expiration dates, CVVs, bank passwords, or PINs.

### Activate hosted checkout

1. Obtain an approved PayMongo merchant account and enable the desired payment methods.
2. Set `PAYMONGO_SECRET_KEY` to the server-side test or live secret key.
3. Set `APP_URL` to the application's canonical public HTTPS origin, without a trailing path.
4. Set `PAYMONGO_PAYMENT_METHODS` to the methods actually enabled for that merchant, for example `card,gcash,paymaya`. Add `qrph` only when enabled.
5. Register `https://YOUR_DOMAIN/api/webhooks/paymongo` in PayMongo and subscribe to `checkout_session.payment.paid`.
6. Set `PAYMONGO_WEBHOOK_SECRET` to that endpoint's signing secret.
7. Use matching test/live credentials and webhook configuration. Test-mode events cannot confirm live-mode payments, or vice versa.
8. Set a strong random `CRON_SECRET` and schedule an authenticated GET request to `/api/cron/holds` every minute. The request must include `Authorization: Bearer YOUR_CRON_SECRET`.
9. Restart the application, make a provider test payment, and verify the webhook confirms the booking. Also verify the return-page reconciliation path.
10. Before launch, replace the illustrative venue information, review policies, test issuer behavior, and perform a small live payment with the owner's authorization.

The app enables hosted checkout only when the secret key, webhook secret, and canonical app URL are all present. Amounts are calculated on the server in PHP; the provider receives centavos. Customer processing fees are not passed on. Email receipts are requested from PayMongo when the player registered with an email; mobile-only players can still use hosted checkout and their in-app receipt.

**Never put secret keys in `NEXT_PUBLIC_*` variables or client components.** The included `.env.example` contains no credentials.

### Payment safety

- Reservations are held for 15 minutes; the court/period is locked in a database transaction.
- A unique court/date/hour index prevents double booking, including simultaneous requests.
- Provider checkout creation uses the booking ID as an idempotency key.
- Signed, timestamp-checked webhooks verify the booking reference, metadata, mode, currency, and exact amount.
- Webhook event IDs are deduplicated in a transaction.
- A redirect alone never confirms payment. The return route retrieves the provider session and verifies its paid payment.
- A paid booking cannot be silently cancelled. Live refunds require merchant/operator handling.
- Expired live sessions are retrieved and explicitly expired before their slots are released.
- If checkout creation times out before its ID is stored, the hold is **not** silently released. Retry checkout while the hold is active to link the idempotent session. After expiry, an operator must reconcile the provider reference before releasing it; this avoids charging a customer for a released court.

## Main files

- `src/app/page.tsx`: server-rendered initial court availability and payment configuration.
- `src/components/booking-app.tsx`: responsive booking application and navigation.
- `src/components/checkout-dialog.tsx`: reservation review, payment selection, and confirmation.
- `src/components/account-dialog.tsx`: reference-style sign-in landing, mobile/email registration, guest entry, and profile editing.
- `src/components/admin-view.tsx`: permission-protected club overview.
- `src/app/auth.css`: sign-in and administrator styling.
- `public/images/pickleball-club.jpg`: custom solid-paddle pickleball photography.
- `src/components/bookings-view.tsx`: history, receipts, cancellations, and alerts.
- `src/components/info-dialog.tsx`: venue, payment support, and booking policies.
- `src/components/ui.tsx`: accessible dialogs and shared visual elements.
- `src/app/globals.css`: complete responsive design and locally hosted fonts.
- `src/db/schema.ts`: Drizzle models for courts, maintenance, users, sessions, bookings, slot locks, payments, and webhook events.
- `src/lib/booking-service.ts`: transactional reservation and reconciliation logic.
- `src/lib/auth.ts`: scrypt password hashing and hashed, expiring session tokens.
- `src/lib/payments.ts`: PayMongo v2 checkout creation, retrieval/expiry, and webhook signature verification.
- `src/app/api/`: backend route handlers.
- `tests/`: browser and API smoke tests.

## API overview

| Method | Route | Purpose |
| --- | --- | --- |
| GET | `/api/health` | PostgreSQL health check |
| GET | `/api/courts` | Court listings |
| GET | `/api/availability?date=YYYY-MM-DD` | Seven-day availability window |
| POST | `/api/auth/register` | Create account and session |
| POST | `/api/auth/login` | Password sign-in |
| GET/PATCH/DELETE | `/api/auth/me` | Read/update profile or sign out |
| GET | `/api/admin/overview` | Admin-only booking totals and recent reservations |
| GET/POST | `/api/bookings` | List own bookings or reserve a court |
| GET/DELETE | `/api/bookings/:id` | Read own booking or cancel eligible booking |
| POST | `/api/bookings/:id/pay` | Confirm demo or create/resume hosted checkout |
| POST | `/api/bookings/:id/sync` | Verify own pending live payment |
| GET | `/api/bookings/:id/calendar` | Download confirmed booking calendar event |
| POST | `/api/webhooks/paymongo` | Signed provider payment notifications |
| GET | `/api/cron/holds` | Secret-protected expired-hold reconciliation |

## Validation

Run from the project root:

- `npx next typegen`
- `npm exec tsc -- --noEmit --pretty false`
- `npm run build`
- `npm run lint`

For browser tests, install Chromium with `npx playwright install chromium`, start the application, then run `npx playwright test`. Set `PLAYWRIGHT_BASE_URL` if the app is not at http://127.0.0.1:3000. Tests create uniquely named demo accounts and clean up their reservations. Live payment tests require your own PayMongo test credentials and are not replaced by fake success claims.

## Production notes

Use HTTPS, a production PostgreSQL database with backups, a scheduler for hold reconciliation, provider monitoring, and edge rate limiting. The included sign-in limiter is per-process; replace it with a shared store for horizontally scaled deployments. Configure real venue contact details and a merchant refund reconciliation process before accepting public live bookings. Review dependency audit findings before deployment. At validation, the runtime audit had no high/critical findings; 12 moderate findings remained in the Drizzle/Eslint development-tool dependency trees. Their suggested fixes require breaking downgrades, so they were not forced.

A source archive is available at `/smashcourt-source.zip` after packaging. It excludes environment secrets, installed dependencies, build output, and test artifacts.
